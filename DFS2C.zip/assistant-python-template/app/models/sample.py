from pydantic import BaseModel, Field


class SampleRequest(BaseModel):
    city: str = Field(
        ...,
        description="The name of the city to ask about",
        min_length=1,
        examples=["Paris", "Tokyo", "New York"],
    )


class SampleResponse(BaseModel):
    success: bool = Field(..., description="Indicates if the operation was successful")
    prompt: str = Field(..., description="The prompt used in the operation")
    data: SampleRequest | None = Field(
        None, description="The sample data if the operation was successful"
    )


class CityRequest(BaseModel):
    city: str = Field(
        ...,
        description="The name of the city to ask about",
        min_length=1,
        examples=["Paris", "Tokyo", "New York"],
    )
    model: str | None = Field(
        default="gpt-4o",
        description="The LLM model to use",
        examples=["gpt-4o", "gpt-4o-mini"],
    )
