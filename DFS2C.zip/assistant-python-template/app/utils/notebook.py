import json
from typing import Optional


def generate_notebook(
    code: str,
    markdown_intro: Optional[str] = None
) -> str:
    """
    Generates a minimal Jupyter notebook as JSON string.
    """

    cells = []

    if markdown_intro:
        cells.append({
            "cell_type": "markdown",
            "metadata": {},
            "source": markdown_intro.splitlines(keepends=True),
        })

    cells.append({
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": code.splitlines(keepends=True),
    })

    notebook = {
        "cells": cells,
        "metadata": {
            "kernelspec": {
                "name": "python3",
                "display_name": "Python 3",
            },
            "language_info": {
                "name": "python",
            },
        },
        "nbformat": 4,
        "nbformat_minor": 5,
    }

    return json.dumps(notebook, indent=2)
