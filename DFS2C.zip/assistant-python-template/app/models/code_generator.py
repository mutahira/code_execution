from pydantic import BaseModel, Field
from typing import Dict, Any, Optional


class CodeGenerationRequest(BaseModel):
    question: str = Field(
        ...,
        description="Question to answer using the dataset"
    )

    dataset_schema: Dict[str, Any] = Field(
        ...,
        description="JSON-LD dataset schema"
    )

    model: Optional[str] = Field(
        default="gpt-4o",
        description="LLM model to use"
    )
