import os
import json

from fastapi.responses import StreamingResponse
from openai import AsyncOpenAI

from app.services.base import BaseStreamingService
from app.templates.builder import PromptBuilder


class CodeGenerationStreamingService(BaseStreamingService):
    """
    Streams executable Python code that answers a question
    based on a dataset schema.
    """

    def __init__(self):
        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY environment variable is required")

        self.client = AsyncOpenAI(api_key=api_key)

    def _build_prompt(self, dataset_schema: dict, question: str) -> str:
        return (
            PromptBuilder("code_generator_prompt.j2")
            .var("dataset_schema", json.dumps(dataset_schema, indent=2))
            .var("question", question)
            .build()
        )

    def generate_code(
        self,
        dataset_schema: dict,
        question: str,
        model: str = "gpt-4o",
    ) -> StreamingResponse:

        prompt = self._build_prompt(dataset_schema, question)

        messages = [
            {
                "role": "system",
                "content": (
                    "You output ONLY executable Python code. "
                    "No text. No markdown. No explanations."
                ),
            },
            {"role": "user", "content": prompt},
        ]

        return self.create_stream_response(
            client=self.client,
            messages=messages,
            model=model,
        )
