import nbformat

def build_notebook(code: str, markdown_intro: str | None):
    nb = nbformat.v4.new_notebook()

    if markdown_intro:
        nb.cells.append(
            nbformat.v4.new_markdown_cell(markdown_intro)
        )

    nb.cells.append(
        nbformat.v4.new_code_cell(code)
    )

    return nbformat.writes(nb)
