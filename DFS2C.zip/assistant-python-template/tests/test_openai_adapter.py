from types import SimpleNamespace

import pytest

from app.core.streaming.adapters.openai import OpenAIStreamAdapter


class FakeAsyncStream:
    def __init__(self, chunks):
        self._chunks = list(chunks)

    def __aiter__(self):
        self._iterator = iter(self._chunks)
        return self

    async def __anext__(self):
        try:
            return next(self._iterator)
        except StopIteration as exc:  # pragma: no cover - defensive
            raise StopAsyncIteration from exc


class FakeChatCompletions:
    def __init__(self, stream):
        self.stream = stream
        self.params = None

    async def create(self, **params):
        self.params = params
        return self.stream


class FakeChat:
    def __init__(self, stream):
        self.completions = FakeChatCompletions(stream)


class FakeClient:
    def __init__(self, stream):
        self.chat = FakeChat(stream)


@pytest.mark.asyncio
async def test_openai_adapter_streams_normalized_chunks():
    usage_info = SimpleNamespace(prompt_tokens=2, completion_tokens=3)

    content_chunk = SimpleNamespace(
        choices=[
            SimpleNamespace(delta=SimpleNamespace(content="Hello"), finish_reason=None)
        ],
        usage=None,
    )

    finish_chunk = SimpleNamespace(
        choices=[
            SimpleNamespace(delta=SimpleNamespace(content=None), finish_reason="stop")
        ],
        usage=usage_info,
    )

    usage_chunk = SimpleNamespace(choices=[], usage=usage_info)

    fake_stream = FakeAsyncStream([content_chunk, finish_chunk, usage_chunk])
    fake_client = FakeClient(fake_stream)

    adapter = OpenAIStreamAdapter(
        fake_client, model="gpt-test", temperature=0.5, max_tokens=10
    )

    messages = [{"role": "user", "content": "Hi"}]

    observed = []
    async for chunk in adapter.stream(messages, temperature=0.7, extra_param="value"):
        observed.append(chunk)

    assert [c.content for c in observed if c.content] == ["Hello"]
    finish_chunks = [c for c in observed if c.finish_reason]
    assert finish_chunks[0].finish_reason == "stop"
    assert finish_chunks[0].usage == {"promptTokens": 2, "completionTokens": 3}
    usage_chunks = [c for c in observed if c.finish_reason and c.usage]
    assert usage_chunks[-1].usage == {"promptTokens": 2, "completionTokens": 3}

    params = fake_client.chat.completions.params
    assert params["model"] == "gpt-test"
    assert params["messages"] is messages
    assert params["temperature"] == 0.7
    assert params["extra_param"] == "value"
    assert params["stream_options"] == {"include_usage": True}


def test_build_params_includes_defaults_and_overrides():
    adapter = OpenAIStreamAdapter(FakeClient(None), model="gpt-default")
    messages = [{"role": "user", "content": "Hello"}]

    params = adapter._build_params(messages)

    assert params["model"] == "gpt-default"
    assert params["messages"] == messages
    assert params["stream"] is True
    assert params["stream_options"] == {"include_usage": True}
