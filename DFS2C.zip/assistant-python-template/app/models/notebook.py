from pydantic import BaseModel

class NotebookGenerateRequest(BaseModel):
    github_owner: str
    github_repo: str
    branch: str = "main"
    notebook_path: str  # e.g. notebooks/generated.ipynb
    code: str
    markdown_intro: str | None = None
    itemId: str | None = None  # For tracking purposes, not used in generation
    datasetFolder: str | None = None  # Optional, for dataset management


class NotebookGenerateResponse(BaseModel):
    github_url: str
    colab_url: str
