from typing import Any, AsyncGenerator, Dict, List

from fastapi.responses import StreamingResponse

from app.core.streaming.base import ProtocolFormatter, StreamAdapter


class LLMStreamer:
    """
    Main orchestrator for LLM streaming

    This class ties together a StreamAdapter (for LLM communication) and
    a ProtocolFormatter (for output formatting) to provide a simple interface
    for streaming LLM responses.
    """

    def __init__(self, adapter: StreamAdapter, formatter: ProtocolFormatter):
        """
        Initialize the streamer

        :param adapter: Stream adapter for the LLM provider
        :param formatter: Protocol formatter for output format
        """
        self.adapter = adapter
        self.formatter = formatter

    async def _generate_stream(
        self, messages: List[Dict[str, Any]], **kwargs
    ) -> AsyncGenerator[str, None]:
        """
        Internal generator that processes the LLM stream and formats it

        :param messages: List of message dictionaries
        :param kwargs: Additional parameters for the adapter
        :yields: Formatted string chunks
        """
        try:
            async for chunk in self.adapter.stream(messages, **kwargs):
                # Format text content chunks
                if chunk.content:
                    formatted = self.formatter.format_text_chunk(chunk.content)
                    if formatted:
                        yield formatted

                # Format finish chunks
                if chunk.finish_reason:
                    formatted = self.formatter.format_finish_chunk(
                        chunk.finish_reason, chunk.usage
                    )
                    if formatted:
                        yield formatted

        except Exception as e:
            # Format and yield error
            error_chunk = self.formatter.format_error_chunk(e)
            if error_chunk:
                yield error_chunk

    def stream(self, messages: List[Dict[str, Any]], **kwargs) -> StreamingResponse:
        """Create a streaming response for the given messages

        :param messages: List of message dictionaries in OpenAI format
        :param kwargs: Additional parameters for the adapter
        :return: FastAPI StreamingResponse ready to be returned from a route
        """
        response = StreamingResponse(
            self._generate_stream(messages, **kwargs),
            media_type="text/event-stream",
        )

        # Add AI SDK protocol header
        response.headers["x-vercel-ai-data-stream"] = "v1"
        response.headers["Cache-Control"] = "no-cache"
        response.headers["Connection"] = "keep-alive"

        return response
