from typing import AsyncGenerator

from fastapi.responses import StreamingResponse

from app.core.streaming.base import ProtocolFormatter
from app.core.streaming.formatters import AISdkFormatter


class TextStreamer:
    """
    Streamer for non-LLM text content

    This class allows streaming plain text content in chunks using the same
    AI SDK protocol format as LLM responses, making it compatible with the
    same client-side handling.
    """

    def __init__(self, formatter: ProtocolFormatter | None = None):
        """
        Initialize the text streamer

        :param formatter: Protocol formatter for output format (defaults to AISdkFormatter)
        """
        self.formatter = formatter or AISdkFormatter()

    async def _generate_stream(
        self,
        text: str,
        chunk_size: int = 1,
        prompt_tokens: int = 0,
        completion_tokens: int | None = None,
    ) -> AsyncGenerator[str, None]:
        """
        Internal generator that chunks text and formats it

        :param text: The text to stream
        :param chunk_size: Number of characters per chunk (default: 1)
        :param prompt_tokens: Number of prompt tokens to report (default: 0)
        :param completion_tokens: Number of completion tokens to report (default: length of text)
        :yields: Formatted string chunks
        """
        try:
            # Stream text in chunks
            for i in range(0, len(text), chunk_size):
                chunk = text[i : i + chunk_size]
                formatted = self.formatter.format_text_chunk(chunk)
                if formatted:
                    yield formatted

            # Send finish chunk with usage
            if completion_tokens is None:
                completion_tokens = len(text)

            usage = {
                "promptTokens": prompt_tokens,
                "completionTokens": completion_tokens,
            }
            formatted = self.formatter.format_finish_chunk("stop", usage)
            if formatted:
                yield formatted

        except Exception as e:
            # Format and yield error
            error_chunk = self.formatter.format_error_chunk(e)
            if error_chunk:
                yield error_chunk

    def stream(
        self,
        text: str,
        chunk_size: int = 1,
        prompt_tokens: int = 0,
        completion_tokens: int | None = None,
    ) -> StreamingResponse:
        """
        Create a streaming response for the given text

        :param text: The text to stream
        :param chunk_size: Number of characters per chunk (default: 1 for character-by-character)
        :param prompt_tokens: Number of prompt tokens to report in usage (default: 0)
        :param completion_tokens: Number of completion tokens to report (default: length of text)
        :return: FastAPI StreamingResponse ready to be returned from a route
        """
        response = StreamingResponse(
            self._generate_stream(text, chunk_size, prompt_tokens, completion_tokens),
            media_type="text/event-stream",
        )

        # Add AI SDK protocol header
        response.headers["x-vercel-ai-data-stream"] = "v1"
        response.headers["Cache-Control"] = "no-cache"
        response.headers["Connection"] = "keep-alive"

        return response
