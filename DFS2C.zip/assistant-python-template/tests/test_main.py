from fastapi.testclient import TestClient

from app import main


def test_root_serves_index_html(tmp_path, monkeypatch):
    client = TestClient(main.app)

    response = client.get("/")
    assert response.status_code == 200
    assert "text/html" in response.headers["content-type"]


def test_demo_serves_streaming_page():
    client = TestClient(main.app)

    response = client.get("/demo")
    assert response.status_code == 200
    assert "text/html" in response.headers["content-type"]
