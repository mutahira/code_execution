import json

import pytest
from fastapi.testclient import TestClient

import app.app_factory as factory


@pytest.fixture
def intercept_openapi_write(monkeypatch):
    captured: dict[str, object] = {}

    def fake_write_json(data, path):
        captured["data"] = data
        captured["path"] = path

    monkeypatch.setattr(factory, "_write_json", fake_write_json)
    return captured


def test_get_application_configures_components(intercept_openapi_write):
    app = factory.get_application()
    client = TestClient(app)

    response = client.post("/sample/show/me", json={"city": "Paris"})
    payload = response.json()

    assert response.status_code == 200
    assert payload["success"] is True
    assert any(m.cls.__name__ == "CORSMiddleware" for m in app.user_middleware)
    assert any(getattr(route, "path", "") == "/static" for route in app.routes)

    assert "data" in intercept_openapi_write
    assert "path" in intercept_openapi_write
    assert intercept_openapi_write["path"].endswith("openapi.json")
    assert intercept_openapi_write["data"]["info"]["title"] == "Template Assistant API"


def test_write_json_writes_file(tmp_path):
    target = tmp_path / "openapi.json"
    sample = {"hello": "world"}

    factory._write_json(sample, target)

    with target.open() as fp:
        loaded = json.load(fp)

    assert loaded == sample
