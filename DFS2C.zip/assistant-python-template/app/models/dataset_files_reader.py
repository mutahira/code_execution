from pydantic import BaseModel, Field, HttpUrl
from typing import Dict, Union, Optional


class DatasetFilesRequest(BaseModel):
    path_or_url: Union[str, HttpUrl] = Field(
        ..., description="Local path, URL, or directory"
    )
    num_lines: int = Field(
        10, description="Number of lines to return per file"
    )


class DatasetFilesResponse(BaseModel):
    success: bool = Field(..., description="Indicates if the operation was successful")
    files_content: Optional[Dict[str, str]] = Field(
        None, description="file_name -> first N lines as raw text"
    )
    error_message: Optional[str] = Field(
        None, description="Error message if operation failed"
    )
