# Architecture and Design Patterns

## Overview

This document explains the architectural patterns, design principles, and how components interact in the application.

## Architecture Layers

The application follows a **layered architecture** with clear separation of concerns:

```
┌─────────────────────────────────────────┐
│         HTTP Layer (Routers)            │  ← FastAPI routes, HTTP concerns
├─────────────────────────────────────────┤
│       Business Logic (Services)         │  ← Application logic, orchestration
├─────────────────────────────────────────┤
│    Infrastructure (Core/Streaming)      │  ← Reusable utilities, LLM adapters
├─────────────────────────────────────────┤
│      Data Models (Pydantic)             │  ← Validation, serialization
└─────────────────────────────────────────┘
```

### Layer Responsibilities

#### 1. HTTP Layer (`app/routers/`)

**Responsibilities:**
- Define HTTP endpoints and paths
- Handle request/response transformation
- Validate input using Pydantic models
- Map HTTP status codes
- Handle HTTP-specific errors
- Add logging decorators

**❌ Should NOT:**
- Contain business logic
- Make LLM calls directly
- Process data
- Build prompts

**Example:**
```python
@router.post("/city", status_code=http.HTTPStatus.OK)
@log(__name__)
def ask_about_city(request: CityRequest):
    """Route handler - only HTTP concerns"""
    try:
        service = SampleStreamingService()
        return service.ask_about_city(
            city=request.city,
            model=request.model or "gpt-4o"
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
```

#### 2. Business Logic Layer (`app/services/`)

**Responsibilities:**
- Implement application logic
- Orchestrate LLM calls
- Build prompts using templates
- Validate business rules
- Coordinate between multiple operations
- Return appropriate responses

**❌ Should NOT:**
- Handle HTTP status codes
- Parse request/response formats
- Know about FastAPI specifics

**Example:**
```python
class SampleStreamingService(BaseStreamingService):
    def ask_about_city(self, city: str, model: str) -> StreamingResponse:
        """Business logic - orchestrate LLM call"""
        # 1. Validate
        if "error" in city.lower():
            raise ValueError("Invalid city name")

        # 2. Build prompt
        prompt = PromptBuilder("prompt.j2").var("city", city).build()

        # 3. Prepare messages
        messages = [
            {"role": "system", "content": "You are helpful."},
            {"role": "user", "content": prompt}
        ]

        # 4. Stream response using infrastructure
        return self.create_stream_response(
            client=self.client,
            messages=messages,
            model=model
        )
```

#### 3. Infrastructure Layer (`app/core/`)

**Responsibilities:**
- Provide reusable utilities
- Abstract LLM provider differences
- Handle streaming protocols
- Format output
- Common decorators

**❌ Should NOT:**
- Contain business logic
- Know about specific endpoints
- Make business decisions

**Example:**
```python
class LLMStreamer:
    """Infrastructure - generic streaming orchestration"""
    def __init__(self, adapter: StreamAdapter, formatter: ProtocolFormatter):
        self.adapter = adapter
        self.formatter = formatter

    def stream(self, messages, **kwargs) -> StreamingResponse:
        """Generic streaming - works for any adapter/formatter"""
        return StreamingResponse(
            self._generate_stream(messages, **kwargs),
            media_type="text/event-stream"
        )
```

#### 4. Data Layer (`app/models/`)

**Responsibilities:**
- Define data structures
- Validate input/output
- Provide serialization
- Document field requirements

**❌ Should NOT:**
- Contain logic
- Make API calls
- Transform data beyond validation

**Example:**
```python
class CityRequest(BaseModel):
    """Data model - pure data structure with validation"""
    city: str = Field(
        ...,
        description="City name",
        min_length=1,
        examples=["Paris"]
    )
    model: str | None = Field(
        default="gpt-4o",
        description="LLM model"
    )
```

## Design Patterns

### 1. Factory Pattern

**Used in:** `app_factory.py`

**Purpose:** Create and configure the FastAPI application

```python
def get_application() -> FastAPI:
    """Factory function creates configured app"""
    _app = FastAPI(title="Template Assistant API")

    # Configure all components
    __configure_routers(_app)
    _configure_cors_policy(_app)
    _configure_static_files(_app)
    _save_openapi_specification(_app)

    return _app
```

**Benefits:**
- Centralized configuration
- Easy to test (can create multiple app instances)
- Clean separation of concerns

### 2. Adapter Pattern

**Used in:** `app/core/streaming/adapters/`

**Purpose:** Normalize different LLM provider APIs into a common interface

```python
class StreamAdapter(ABC):
    """Abstract interface"""
    @abstractmethod
    async def stream(self, messages, **kwargs) -> AsyncGenerator[StreamChunk, None]:
        pass

class OpenAIStreamAdapter(StreamAdapter):
    """Concrete adapter for OpenAI"""
    async def stream(self, messages, **kwargs):
        # Convert OpenAI-specific response to StreamChunk
        stream = await self.client.chat.completions.create(...)
        async for chunk in stream:
            yield StreamChunk(content=chunk.choices[0].delta.content)
```

**Benefits:**
- Easy to add new LLM providers
- Services don't need to know provider details
- Swap providers without changing business logic

**To add a new provider:**

```python
class AnthropicStreamAdapter(StreamAdapter):
    async def stream(self, messages, **kwargs):
        # Implement Anthropic-specific streaming
        async for chunk in self.client.messages.create(...):
            # Convert to common StreamChunk format
            yield StreamChunk(content=chunk.delta.text)
```

### 3. Strategy Pattern

**Used in:** `app/core/streaming/formatters.py`

**Purpose:** Different output formatting strategies

```python
class ProtocolFormatter(ABC):
    """Strategy interface"""
    @abstractmethod
    def format_text_chunk(self, content: str) -> str:
        pass

class AISdkFormatter(ProtocolFormatter):
    """Concrete strategy for AI SDK protocol"""
    def format_text_chunk(self, content: str) -> str:
        return f"0:{json.dumps(content)}\n"

class ServerSentEventsFormatter(ProtocolFormatter):
    """Alternative strategy for SSE protocol"""
    def format_text_chunk(self, content: str) -> str:
        return f"data: {json.dumps({'text': content})}\n\n"
```

**Benefits:**
- Easy to switch output formats
- Can add new formats without changing streaming logic
- Client-specific formatting

### 4. Template Method Pattern

**Used in:** `BaseStreamingService`

**Purpose:** Define skeleton of streaming operation, let subclasses customize

```python
class BaseStreamingService:
    """Base class with template method"""

    def create_stream_response(self, client, messages, model, **kwargs):
        """Template method - defines the steps"""
        # Step 1: Create adapter
        adapter = OpenAIStreamAdapter(client, model=model)

        # Step 2: Create formatter
        formatter = AISdkFormatter()

        # Step 3: Create streamer
        streamer = LLMStreamer(adapter, formatter)

        # Step 4: Stream
        return streamer.stream(messages, **kwargs)

class SampleStreamingService(BaseStreamingService):
    """Subclass customizes specific parts"""
    def ask_about_city(self, city: str, model: str):
        # Customize: build messages
        messages = self._build_messages(city)

        # Use template method
        return self.create_stream_response(
            client=self.client,
            messages=messages,
            model=model
        )
```

**Benefits:**
- Consistent streaming behavior
- Services focus on business logic
- Reusable infrastructure code

### 5. Builder Pattern

**Used in:** `app/templates/builder.py`

**Purpose:** Construct complex prompts step by step

```python
prompt = PromptBuilder("prompt.j2") \
    .var("city", "Paris") \
    .var("include_history", True) \
    .var("max_facts", 5) \
    .build()
```

**Benefits:**
- Readable prompt construction
- Fluent interface (method chaining)
- Validation before building
- Reusable templates

### 6. Dependency Injection

**Used in:** Service initialization

**Purpose:** Inject dependencies rather than creating them internally

```python
# ❌ Bad: Hard to test, tightly coupled
class SampleService:
    def __init__(self):
        self.client = AsyncOpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

# ✅ Good: Easy to test, loosely coupled
class SampleService:
    def __init__(self, client: AsyncOpenAI):
        self.client = client

# In production
service = SampleService(client=AsyncOpenAI(api_key=api_key))

# In tests
service = SampleService(client=MockClient())
```

**Note:** Current code uses environment-based initialization for simplicity, but can be refactored to full DI if needed.

## Request Flow Patterns

### Non-Streaming Request

```
┌──────────┐     ┌──────────┐     ┌──────────┐     ┌──────────┐
│  Client  │────▶│  Router  │────▶│ Service  │────▶│  Model   │
└──────────┘     └──────────┘     └──────────┘     └──────────┘
      │                │                 │                 │
      │                │           ┌─────▼─────┐          │
      │                │           │  Process  │          │
      │                │           │   Logic   │          │
      │                │           └─────┬─────┘          │
      │                │                 │                │
      │           ┌────▼────┐       ┌────▼────┐          │
      │           │ Validate│       │  Build  │          │
      │           │  Input  │       │  Output │          │
      │           └────┬────┘       └────┬────┘          │
      │                │                 │                │
      │◀───────────────┴─────────────────┴────────────────┘
      │
   Response
```

**Code Example:**

```python
# 1. Client request
response = requests.post("/sample/show/me", json={"city": "Paris"})

# 2. Router receives and validates
@router.post("/show/me", response_model=SampleResponse)
def show_me_how_it_works(request: SampleRequest):

    # 3. Service processes
    prompt = get_prompt(city=request.city)

    # 4. Return model
    return SampleResponse(
        success=True,
        prompt=prompt,
        data=request
    )
```

### Streaming Request

```
┌──────────┐     ┌──────────┐     ┌──────────┐     ┌──────────┐
│  Client  │────▶│  Router  │────▶│ Service  │────▶│ Streamer │
└──────────┘     └──────────┘     └──────────┘     └──────────┘
      │                │                 │                 │
      │                │                 │           ┌─────▼─────┐
      │                │                 │           │  Adapter  │
      │                │                 │           └─────┬─────┘
      │                │                 │                 │
      │                │                 │           ┌─────▼─────┐
      │                │                 │           │    LLM    │
      │                │                 │           └─────┬─────┘
      │                │                 │                 │
      │                │            ┌────▼────┐       ┌────▼────┐
      │                │            │Formatter│◀──────│  Chunk  │
      │                │            └────┬────┘       └─────────┘
      │                │                 │
      │◀───────────────┴─────────────────┴──── Streaming chunks ───
      │  0:"Paris"
      │  0:" is"
      │  0:" beautiful"
      │  e:{"finishReason":"stop"}
```

**Code Example:**

```python
# 1. Client opens stream
async with client.stream('POST', '/sample/city', json={"city": "Paris"}) as response:

    # 2. Router delegates to service
    @router.post("/city", response_class=StreamingResponse)
    def ask_about_city(request: CityRequest):
        service = SampleStreamingService()
        return service.ask_about_city(request.city, request.model)

    # 3. Service creates stream
    def ask_about_city(self, city, model):
        messages = [{"role": "user", "content": get_prompt(city)}]
        return self.create_stream_response(
            client=self.client,
            messages=messages,
            model=model
        )

    # 4. Streamer orchestrates
    def stream(self, messages):
        async for chunk in self.adapter.stream(messages):
            formatted = self.formatter.format_text_chunk(chunk.content)
            yield formatted

    # 5. Client receives chunks
    async for line in response.aiter_lines():
        print(line)  # 0:"Paris", 0:" is", ...
```

## Error Handling Patterns

### Layered Error Handling

Each layer handles its own concerns:

```python
# Layer 1: Router - HTTP errors
@router.post("/city")
def ask_about_city(request: CityRequest):
    try:
        service = SampleStreamingService()
        return service.ask_about_city(request.city)

    except ValueError as e:
        # Client error - bad input
        raise HTTPException(status_code=400, detail=str(e))

    except Exception as e:
        # Server error - unexpected
        raise HTTPException(
            status_code=500,
            detail=f"Failed to process: {str(e)}"
        )

# Layer 2: Service - Business validation
class SampleStreamingService:
    def ask_about_city(self, city: str):
        if "error" in city.lower():
            raise ValueError("Invalid city name")

        if not self.client:
            raise ValueError("Service not initialized")

        # Continue processing...

# Layer 3: Infrastructure - Stream errors
class LLMStreamer:
    async def _generate_stream(self, messages):
        try:
            async for chunk in self.adapter.stream(messages):
                yield self.formatter.format_text_chunk(chunk.content)

        except Exception as e:
            # Format error as protocol chunk
            error_chunk = self.formatter.format_error_chunk(e)
            yield error_chunk
```

### Custom Exceptions

```python
# app/errors.py
class IncorrectAPIInvocationError(HTTPException):
    """Raised when API is invoked incorrectly"""
    def __init__(self, msg: str):
        super().__init__(status_code=400, detail=msg)

# Usage in service
def get_prompt(city: str) -> str:
    if "error" in city.lower():
        raise IncorrectAPIInvocationError(
            msg="City name contains invalid word"
        )
    return build_prompt(city)
```

## Configuration Patterns

### Environment-Based Configuration

```python
# Service initialization
class SampleStreamingService:
    def __init__(self):
        # Required environment variable
        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY required")

        self.client = AsyncOpenAI(api_key=api_key)

# Optional with defaults
class ConfigurableService:
    def __init__(self):
        self.model = os.environ.get("DEFAULT_MODEL", "gpt-4o")
        self.temperature = float(os.environ.get("TEMPERATURE", "0.7"))
        self.max_tokens = int(os.environ.get("MAX_TOKENS", "4096"))
```

### Factory Configuration

```python
# app_factory.py - Centralized configuration
def get_application() -> FastAPI:
    app = FastAPI(
        title="Assistant API",
        description="AI-powered assistant",
        version="1.0.0"
    )

    # Configure CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"]
    )

    # Register routers
    app.include_router(sample.router)

    return app
```

## Logging Pattern

### Decorator-Based Logging

```python
# Add to all route handlers
@router.post("/city")
@log(__name__)  # Logs args and response
def ask_about_city(request: CityRequest):
    pass

# Implementation in app/core/decorators.py
def log(logger_name: str):
    logger = logging.getLogger(logger_name)

    def log_func(route: Callable):
        @wraps(route)
        def wrapper(*args, **kwargs):
            logger.debug(">>>> Entering route")
            logger.debug(f"Args: {args}, Kwargs: {kwargs}")

            response = route(*args, **kwargs)

            logger.debug("<<<< Exiting route")
            logger.debug(f"Response: {response}")

            return response
        return wrapper
    return log_func
```

**To see logs:**

```bash
# Set logging level
export LOG_LEVEL=DEBUG

# Or in code
import logging
logging.basicConfig(level=logging.DEBUG)
```

## Testing Patterns

### Service Testing with Mocks

```python
def test_service_uses_client(monkeypatch):
    """Test service behavior by mocking dependencies"""

    # Capture calls
    captured = {}

    # Mock OpenAI client
    class MockClient:
        async def chat_completions_create(self, **kwargs):
            captured["kwargs"] = kwargs
            return mock_response

    # Inject mock
    monkeypatch.setattr(module, "AsyncOpenAI", lambda api_key: MockClient())

    # Test service
    service = SampleService()
    service.ask_about_city("Paris")

    # Verify
    assert captured["kwargs"]["model"] == "gpt-4o"
```

### Router Testing with Stubs

```python
def test_router_handles_errors(monkeypatch):
    """Test router error handling with service stub"""

    # Stub that raises error
    class FailingService:
        def ask_about_city(self, city, model):
            raise ValueError("bad input")

    # Inject stub
    monkeypatch.setattr(module, "SampleStreamingService", FailingService)

    # Test
    client = TestClient(app)
    response = client.post("/sample/city", json={"city": "Test"})

    # Verify error handling
    assert response.status_code == 500
    assert "bad input" in response.json()["detail"]
```

## Best Practices Summary

### Separation of Concerns

✅ **Do:**
- Keep HTTP logic in routers
- Keep business logic in services
- Keep infrastructure in core/
- Keep data structures in models/

❌ **Don't:**
- Put business logic in routers
- Put HTTP concerns in services
- Mix infrastructure and business logic

### Dependency Management

✅ **Do:**
- Inject dependencies when possible
- Use environment variables for config
- Initialize clients in `__init__`
- Validate configuration early

❌ **Don't:**
- Hardcode configuration
- Create clients in methods
- Skip validation
- Hide dependencies

### Error Handling

✅ **Do:**
- Handle errors at appropriate layer
- Use custom exceptions for business errors
- Provide descriptive error messages
- Log errors appropriately

❌ **Don't:**
- Catch all exceptions silently
- Return generic error messages
- Mix error handling concerns
- Expose internal details to clients

### Code Organization

✅ **Do:**
- Follow established file structure
- Use consistent naming
- Keep files focused and small
- Document public interfaces

❌ **Don't:**
- Create catch-all utility files
- Mix concerns in single file
- Skip documentation
- Create deep nesting

---

**Next:** [Streaming Infrastructure](./04-streaming.md) - Deep dive into streaming
