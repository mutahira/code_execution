import pytest

import app.services.base as base_module
import app.services.sample as sample_module
from app.errors import IncorrectAPIInvocationError
from app.services.base import BaseStreamingService
from app.services.sample import SampleStreamingService, get_prompt


def test_base_service_create_stream_response_uses_streamer(monkeypatch):
    captured = {}

    class FakeAdapter:
        def __init__(self, client, model="gpt-4o"):
            captured["client"] = client
            captured["model"] = model

    class FakeLLMStreamer:
        def __init__(self, adapter, formatter):
            captured["adapter"] = adapter
            captured["formatter"] = formatter

        def stream(self, messages, **kwargs):
            captured["messages"] = messages
            captured["kwargs"] = kwargs
            return "stream-response"

    monkeypatch.setattr(base_module, "OpenAIStreamAdapter", FakeAdapter)
    monkeypatch.setattr(base_module, "LLMStreamer", FakeLLMStreamer)

    service = BaseStreamingService()
    result = service.create_stream_response(
        client="client", messages=[{"msg": 1}], model="model-x", temperature=0.9
    )

    assert result == "stream-response"
    assert captured["client"] == "client"
    assert captured["model"] == "model-x"
    assert captured["messages"] == [{"msg": 1}]
    assert captured["kwargs"]["temperature"] == 0.9


def test_base_service_create_text_stream_response(monkeypatch):
    captured = {}

    class FakeTextStreamer:
        def stream(self, text, chunk_size, prompt_tokens, completion_tokens):
            captured["params"] = (text, chunk_size, prompt_tokens, completion_tokens)
            return "text-stream"

    monkeypatch.setattr(base_module, "TextStreamer", lambda: FakeTextStreamer())

    service = BaseStreamingService()
    result = service.create_text_stream_response(
        "hello", chunk_size=2, prompt_tokens=3, completion_tokens=4
    )

    assert result == "text-stream"
    assert captured["params"] == ("hello", 2, 3, 4)


def test_get_prompt_success():
    prompt = get_prompt("Berlin")
    assert "Berlin" in prompt


def test_get_prompt_rejects_invalid_city():
    with pytest.raises(IncorrectAPIInvocationError):
        get_prompt("error town")


def test_sample_service_requires_api_key(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    with pytest.raises(ValueError):
        SampleStreamingService()


def test_sample_service_ask_about_city(monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")

    class DummyClient:
        def __init__(self, api_key):
            self.api_key = api_key

    captured = {}

    def fake_create_stream_response(self, client, messages, model):
        captured["client"] = client
        captured["messages"] = messages
        captured["model"] = model
        return "stream"

    monkeypatch.setattr(sample_module, "AsyncOpenAI", DummyClient)
    monkeypatch.setattr(
        BaseStreamingService, "create_stream_response", fake_create_stream_response
    )

    service = SampleStreamingService()
    result = service.ask_about_city("Lisbon", model="gpt-custom")

    assert result == "stream"
    assert captured["client"].api_key == "test-key"
    assert captured["model"] == "gpt-custom"
    assert (
        captured["messages"][1]["content"].lower().startswith("you are a knowledgeable")
    )


def test_sample_service_stream_story(monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")

    class DummyClient:
        def __init__(self, api_key):
            self.api_key = api_key

    def fake_create_stream_response(self, client, messages, model):
        return "unused"

    captured = {}

    def fake_create_text_stream(
        self, text, chunk_size, prompt_tokens, completion_tokens
    ):
        captured["params"] = (text, chunk_size, prompt_tokens, completion_tokens)
        return "story"

    monkeypatch.setattr(sample_module, "AsyncOpenAI", DummyClient)
    monkeypatch.setattr(
        BaseStreamingService, "create_stream_response", fake_create_stream_response
    )
    monkeypatch.setattr(
        BaseStreamingService, "create_text_stream_response", fake_create_text_stream
    )

    service = SampleStreamingService()
    result = service.stream_story(chunk_size=7)

    assert result == "story"
    text, chunk_size, prompt_tokens, completion_tokens = captured["params"]
    assert chunk_size == 7
    assert completion_tokens == len(text)
