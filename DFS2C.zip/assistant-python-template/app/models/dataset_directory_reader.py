from pydantic import BaseModel, Field
from typing import List, Optional

class ReadDirectoryRequest(BaseModel):
    path: str = Field(
        ...,
        description="Path to the dataset directory",
        examples=["/home/user/dataset", "./data/train"]
    )

class DirectoryNode(BaseModel):
    name: str = Field(..., description="Directory name")
    type: str = Field(..., description="Type of node, always 'directory'")
    files_count: int = Field(..., description="Number of files in this directory")
    sample_files: List[str] = Field(..., description="Sample of files or fuzzy group")
    children: Optional[List["DirectoryNode"]] = Field(
        default_factory=list, description="List of subdirectories"
    )

DirectoryNode.update_forward_refs()

class ReadDirectoryResponse(BaseModel):
    success: bool = Field(..., description="Indicates if the operation was successful")
    structure: Optional[DirectoryNode] = Field(
        None, description="Hierarchical directory structure with fuzzy groups"
    )
    error_message: Optional[str] = Field(None, description="Error message if operation failed")
