import http

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse

from app.core.decorators import log
from app.models.sample import CityRequest, SampleRequest, SampleResponse
from app.services.sample import SampleStreamingService, get_prompt

router = APIRouter(prefix="/sample", tags=["Sample Tagline"])


@router.post(
    "/show/me",
    status_code=http.HTTPStatus.OK,
    response_model=SampleResponse,
)
@log(__name__)
def show_me_how_it_works(request: SampleRequest):
    """
    Sample endpoint to demonstrate how to create an endpoint in FastAPI.

    This endpoint accepts a `SampleRequest` object and returns a `SampleResponse` object.
    """
    prompt = get_prompt(city=request.city)
    return SampleResponse(success=True, prompt=prompt, data=request)


@router.post(
    "/city",
    status_code=http.HTTPStatus.OK,
    response_class=StreamingResponse,
)
@log(__name__)
def ask_about_city(request: CityRequest):
    """
    Ask about a city and get a streaming response

    This endpoint demonstrates how to use the streaming infrastructure
    with a simple use case: asking the LLM about a city.

    The response is streamed in AI SDK data stream format (v1) which can be
    consumed by Vercel AI SDK or any client that understands the protocol.

    Example request:
    ```json
    {
        "city": "Paris",
        "model": "gpt-4o"
    }
    ```

    The response will be streamed with the following format:
    - `0:"content"` - Text chunks
    - `e:{metadata}` - End of stream with usage info
    """
    try:
        service = SampleStreamingService()
        return service.ask_about_city(
            city=request.city, model=request.model or "gpt-4o"
        )
    except ValueError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Failed to process city request: {str(e)}"
        )


@router.get(
    "/story",
    status_code=http.HTTPStatus.OK,
    response_class=StreamingResponse,
)
@log(__name__)
def stream_story(chunk_size: int = 5):
    """
    Stream a predefined story as non-LLM content

    This endpoint demonstrates how to stream plain text content without using an LLM.
    The text is streamed in the same AI SDK protocol format, making it compatible
    with the same client-side handling.

    Query parameters:
    - `chunk_size` (optional): Number of characters per chunk (default: 5)

    Example usage:
    ```
    GET /sample/story?chunk_size=10
    ```

    The response will be streamed with the following format:
    - `0:"content"` - Text chunks
    - `e:{metadata}` - End of stream with usage info (tokens set to 0 or predefined values)
    """
    try:
        service = SampleStreamingService()
        return service.stream_story(chunk_size=chunk_size)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to stream story: {str(e)}")
