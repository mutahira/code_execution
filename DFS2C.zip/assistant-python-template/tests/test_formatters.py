from app.core.streaming.formatters import AISdkFormatter


def test_formatter_format_text_chunk():
    formatter = AISdkFormatter()
    assert formatter.format_text_chunk("hello") == '0:"hello"\n'
    assert formatter.format_text_chunk(None) == ""


def test_formatter_finish_chunk_includes_defaults():
    formatter = AISdkFormatter()
    output = formatter.format_finish_chunk("stop")
    assert output.startswith("e:")
    assert '"finishReason": "stop"' in output
    assert '"promptTokens": 0' in output
    assert '"completionTokens": 0' in output


def test_formatter_error_chunk_contains_exception_details():
    formatter = AISdkFormatter()
    output = formatter.format_error_chunk(ValueError("bad"))
    assert output.startswith("3:")
    assert '"error": "bad"' in output
    assert '"type": "ValueError"' in output
