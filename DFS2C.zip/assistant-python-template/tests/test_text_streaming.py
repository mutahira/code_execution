import pytest

from app.core.streaming.streamers.text import TextStreamer


class BrokenFormatter:
    def format_text_chunk(self, content: str) -> str:
        raise RuntimeError("failed to format")

    def format_finish_chunk(self, finish_reason: str, usage=None) -> str:
        return "finish"

    def format_error_chunk(self, error: Exception) -> str:
        return f"error:{error}"


class TestTextStreaming:

    @pytest.mark.asyncio
    async def test_text_streaming_basic(self):
        streamer = TextStreamer()

        text = "Here is a story"
        response = streamer.stream(
            text=text,
            chunk_size=5,
            prompt_tokens=2,
            completion_tokens=15,
        )

        chunks = []
        async for chunk in response.body_iterator:
            chunks.append(chunk)

        assert response.headers["x-vercel-ai-data-stream"] == "v1"
        assert response.headers["Cache-Control"] == "no-cache"

        complete_output = "".join(chunks)
        assert '0:"Here' in complete_output
        assert 'e:{"finishReason": "stop"' in complete_output
        assert '"promptTokens": 2' in complete_output
        assert '"completionTokens": 15' in complete_output

    @pytest.mark.asyncio
    async def test_text_streaming_defaults_completion_tokens(self):
        streamer = TextStreamer()
        text = "Test"

        response = streamer.stream(text=text, chunk_size=2)

        chunks = []
        async for chunk in response.body_iterator:
            chunks.append(chunk)

        finish = next(chunk for chunk in chunks if chunk.startswith("e:"))
        assert '"completionTokens": 4' in finish

    @pytest.mark.asyncio
    async def test_text_streaming_error_handling(self):
        streamer = TextStreamer(formatter=BrokenFormatter())

        response = streamer.stream(text="oops")

        chunks = []
        async for chunk in response.body_iterator:
            chunks.append(chunk)

        assert any(chunk.startswith("error:") for chunk in chunks)
