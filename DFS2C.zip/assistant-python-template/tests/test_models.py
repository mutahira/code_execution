import pytest
from pydantic import ValidationError

from app.models.sample import CityRequest, SampleRequest, SampleResponse


def test_sample_request_requires_city():
    request = SampleRequest(city="Paris")
    assert request.city == "Paris"

    with pytest.raises(ValidationError):
        SampleRequest(city="")


def test_sample_response_serialization():
    request = SampleRequest(city="Paris")
    response = SampleResponse(success=True, prompt="prompt", data=request)

    serialized = response.model_dump()
    assert serialized["success"] is True
    assert serialized["data"]["city"] == "Paris"


def test_city_request_has_default_model():
    payload = CityRequest(city="Tokyo")

    assert payload.model == "gpt-4o"
    payload = CityRequest(city="Berlin", model="gpt-4o-mini")
    assert payload.model == "gpt-4o-mini"
