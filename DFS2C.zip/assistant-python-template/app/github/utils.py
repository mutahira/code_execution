from fastapi import HTTPException
from app.github.pocketbase_client import pb_admin

def get_installation_id_for_user(user_id: str) -> int:
    records = pb_admin.collection("github_installations").get_list(
    page=1,
    per_page=1,
    query_params={
        "filter": f'user_id="{user_id}"'
    }
)

    if not records.items:
        raise HTTPException(
            status_code=400,
            detail="GitHub not connected"
        )

    return records.items[0].installation_id
