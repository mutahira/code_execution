from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pocketbase import PocketBase
from app.github.pocketbase_client import pb_user

security = HTTPBearer()

def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
):
    token = credentials.credentials

    try:
        # Authenticate token with PocketBase
        pb_user.auth_store.save(token, None)

        user = pb_user.collection("users").auth_refresh()
        return user.record.id  # THIS IS YOUR USER ID

    except Exception:
        raise HTTPException(
            status_code=401,
            detail="Invalid or expired authentication token"
        )
