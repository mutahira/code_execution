from pydantic import BaseModel
from typing import Any

class ResultPayload(BaseModel):
    itemId: str
    result: dict
    outputName: Any