# Streaming Infrastructure

## Overview

The streaming infrastructure enables real-time streaming of LLM responses using the **AI SDK protocol format (v1)**. It's designed to be clean, extensible, and provider-agnostic.

## Architecture

### Component Diagram

```
                    ┌────────────────────────┐
                    │   BaseStreamingService │
                    │   (Your Service Layer) │
                    └───────────┬────────────┘
                                │
                                │ uses
                                ▼
                    ┌────────────────────────┐
                    │      LLMStreamer       │
                    │   (Orchestrator)       │
                    └────┬──────────────┬────┘
                         │              │
                    uses │              │ uses
                         ▼              ▼
              ┌──────────────┐   ┌─────────────────┐
              │StreamAdapter │   │ProtocolFormatter│
              │  (Provider)  │   │   (Output)      │
              └──────┬───────┘   └────────┬────────┘
                     │                    │
            ┌────────┴────────┐    ┌──────┴───────┐
            ▼                 ▼    ▼              ▼
    ┌──────────────┐   ┌──────────┐  ┌─────────┐
    │OpenAIAdapter │   │Anthropic │  │AISdk    │  .....
    │              │   │Adapter   │  │Formatter│
    └──────────────┘   └──────────┘  └─────────┘
```

### Core Components

#### 1. `StreamChunk` (Data Object)

**Location:** `app/core/streaming/base.py`

**Purpose:** Represents a chunk of data from an LLM stream

```python
class StreamChunk:
    """A normalized chunk of streaming data"""

    def __init__(
        self,
        content: str | None = None,
        finish_reason: str | None = None,
        usage: Dict[str, int] | None = None
    ):
        self.content = content              # Text content
        self.finish_reason = finish_reason  # "stop", "length", etc.
        self.usage = usage                  # Token counts
```

**Usage:**
```python
# Content chunk
chunk = StreamChunk(content="Hello")

# Finish chunk
chunk = StreamChunk(
    finish_reason="stop",
    usage={"promptTokens": 10, "completionTokens": 50}
)
```

#### 2. `StreamAdapter` (Abstract Base Class)

**Location:** `app/core/streaming/base.py`

**Purpose:** Abstract interface for LLM providers

```python
class StreamAdapter(ABC):
    """Normalize different LLM provider APIs"""

    @abstractmethod
    async def stream(
        self,
        messages: List[Dict[str, Any]],
        **kwargs
    ) -> AsyncGenerator[StreamChunk, None]:
        """
        Stream responses from LLM provider

        :param messages: List of messages in OpenAI format
        :param kwargs: Provider-specific parameters
        :yields: StreamChunk objects
        """
        pass
```

**Responsibilities:**
- Connect to LLM provider
- Handle provider-specific API details
- Convert provider responses to `StreamChunk` format
- Handle provider-specific errors

#### 3. `ProtocolFormatter` (Abstract Base Class)

**Location:** `app/core/streaming/base.py`

**Purpose:** Format chunks into specific protocol formats

```python
class ProtocolFormatter(ABC):
    """Convert StreamChunks to protocol-specific format"""

    @abstractmethod
    def format_text_chunk(self, content: str) -> str:
        """Format a text content chunk"""
        pass

    @abstractmethod
    def format_finish_chunk(
        self,
        finish_reason: str,
        usage: Dict[str, int] | None = None
    ) -> str:
        """Format the final chunk"""
        pass

    @abstractmethod
    def format_error_chunk(self, error: Exception) -> str:
        """Format an error chunk"""
        pass
```

**Responsibilities:**
- Format text chunks for client consumption
- Format metadata (finish reason, usage)
- Format errors in protocol-specific way

#### 4. `LLMStreamer` (Orchestrator)

**Location:** `app/core/streaming/streamers/llm.py`

**Purpose:** Orchestrate streaming by combining adapter and formatter

```python
class LLMStreamer:
    """Main orchestrator for LLM streaming"""

    def __init__(
        self,
        adapter: StreamAdapter,
        formatter: ProtocolFormatter
    ):
        self.adapter = adapter
        self.formatter = formatter

    def stream(
        self,
        messages: List[Dict[str, Any]],
        **kwargs
    ) -> StreamingResponse:
        """
        Create a streaming response

        :param messages: Messages to send to LLM
        :param kwargs: Additional parameters
        :return: FastAPI StreamingResponse
        """
        return StreamingResponse(
            self._generate_stream(messages, **kwargs),
            media_type="text/event-stream",
            headers={
                "x-vercel-ai-data-stream": "v1",
                "Cache-Control": "no-cache",
                "Connection": "keep-alive"
            }
        )
```

#### 5. `BaseStreamingService` (Helper Base Class)

**Location:** `app/services/base.py`

**Purpose:** Provide convenient streaming methods for services

```python
class BaseStreamingService:
    """Base class for services that need streaming"""

    def create_stream_response(
        self,
        client: AsyncOpenAI,
        messages: List[Dict[str, Any]],
        model: str = "gpt-4o",
        **kwargs
    ) -> StreamingResponse:
        """
        Create LLM streaming response with defaults

        :param client: AsyncOpenAI client
        :param messages: Messages in OpenAI format
        :param model: Model name
        :param kwargs: Additional OpenAI parameters
        :return: StreamingResponse
        """
        adapter = OpenAIStreamAdapter(client, model=model)
        formatter = AISdkFormatter()
        streamer = LLMStreamer(adapter, formatter)
        return streamer.stream(messages, **kwargs)
```

## Data Flow

### Streaming Request Flow

```
1. Client Request
   │
   ├─▶ POST /sample/city {"city": "Paris"}
   │

2. Router Handler
   │
   ├─▶ @router.post("/city")
   │   def ask_about_city(request):
   │       service = SampleStreamingService()
   │       return service.ask_about_city(request.city)
   │

3. Service Business Logic
   │
   ├─▶ def ask_about_city(self, city):
   │       messages = [{"role": "user", "content": get_prompt(city)}]
   │       return self.create_stream_response(
   │           client=self.client,
   │           messages=messages,
   │           model="gpt-4o"
   │       )
   │

4. BaseStreamingService Helper
   │
   ├─▶ def create_stream_response(self, client, messages, model):
   │       adapter = OpenAIStreamAdapter(client, model)
   │       formatter = AISdkFormatter()
   │       streamer = LLMStreamer(adapter, formatter)
   │       return streamer.stream(messages)
   │

5. LLMStreamer Orchestration
   │
   ├─▶ async def _generate_stream(self, messages):
   │       async for chunk in self.adapter.stream(messages):
   │           if chunk.content:
   │               yield self.formatter.format_text_chunk(chunk.content)
   │           if chunk.finish_reason:
   │               yield self.formatter.format_finish_chunk(...)
   │

6. OpenAIStreamAdapter
   │
   ├─▶ async def stream(self, messages):
   │       stream = await self.client.chat.completions.create(
   │           model=self.model,
   │           messages=messages,
   │           stream=True
   │       )
   │       async for chunk in stream:
   │           yield StreamChunk(content=chunk.choices[0].delta.content)
   │

7. AISdkFormatter
   │
   ├─▶ def format_text_chunk(self, content):
   │       return f'0:{json.dumps(content)}\n'
   │

8. Client Receives
   │
   └─▶ 0:"Paris"
       0:" is"
       0:" the"
       0:" capital"
       e:{"finishReason":"stop","usage":{...}}
```

## AI SDK Protocol Format

### Protocol Specification

The AI SDK v1 protocol uses prefixes to identify chunk types:

| Prefix | Type | Description | Example |
|--------|------|-------------|---------|
| `0:` | Text | Content chunk | `0:"Hello world"` |
| `e:` | End | Stream completion with metadata | `e:{"finishReason":"stop",...}` |
| `3:` | Error | Error information | `3:{"error":"API error",...}` |

### Response Headers

```http
HTTP/1.1 200 OK
Content-Type: text/event-stream
Cache-Control: no-cache
Connection: keep-alive
x-vercel-ai-data-stream: v1
```

### Example Response

```
0:"Paris"
0:" is"
0:" the"
0:" capital"
0:" of"
0:" France."
e:{"finishReason":"stop","usage":{"promptTokens":45,"completionTokens":150},"isContinued":false}
```

### Finish Metadata Schema

```json
{
  "finishReason": "stop",           // "stop", "length", "content_filter"
  "usage": {
    "promptTokens": 45,              // Input tokens
    "completionTokens": 150          // Output tokens
  },
  "isContinued": false               // Whether stream continues
}
```

### Error Schema

```json
{
  "error": "API rate limit exceeded",  // Error message
  "type": "RateLimitError"            // Exception type
}
```

## Implementing New Features

### Adding a New LLM Provider Adapter

**Example: Anthropic Claude**

```python
from typing import Any, AsyncGenerator, Dict, List
from anthropic import AsyncAnthropic
from app.core.streaming.base import StreamAdapter, StreamChunk

class AnthropicStreamAdapter(StreamAdapter):

    def __init__(
        self,
        client: AsyncAnthropic,
        model: str = "claude-3-opus-20240229",
        max_tokens: int = 4096
    ):
        self.client = client
        self.model = model
        self.max_tokens = max_tokens

    async def stream(
        self,
        messages: List[Dict[str, Any]],
        **kwargs
    ) -> AsyncGenerator[StreamChunk, None]:
        """
        Stream from Anthropic API

        Note: Anthropic uses different message format,
        we need to convert from OpenAI format
        """
        # Convert messages if needed
        anthropic_messages = self._convert_messages(messages)

        # Call Anthropic API
        async with self.client.messages.stream(
            model=kwargs.get("model", self.model),
            max_tokens=kwargs.get("max_tokens", self.max_tokens),
            messages=anthropic_messages
        ) as stream:
            async for event in stream:
                # Handle different event types
                if event.type == "content_block_delta":
                    # Text content
                    yield StreamChunk(content=event.delta.text)

                elif event.type == "message_stop":
                    # End of stream
                    usage = self._extract_usage(stream)
                    yield StreamChunk(
                        finish_reason="stop",
                        usage=usage
                    )

    def _convert_messages(
        self,
        messages: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Convert OpenAI format to Anthropic format"""
        # Anthropic doesn't use 'system' role in messages
        # Extract system message and convert
        system = None
        anthropic_messages = []

        for msg in messages:
            if msg["role"] == "system":
                system = msg["content"]
            else:
                anthropic_messages.append(msg)

        return anthropic_messages

    def _extract_usage(self, stream) -> Dict[str, int]:
        """Extract token usage from stream"""
        # Anthropic provides usage info differently
        return {
            "promptTokens": stream.usage.input_tokens,
            "completionTokens": stream.usage.output_tokens
        }
```

**Usage:**

```python
from anthropic import AsyncAnthropic
from app.core.streaming.adapters.anthropic import AnthropicStreamAdapter
from app.core.streaming.formatters import AISdkFormatter
from app.core.streaming.streamers.llm import LLMStreamer

class AnthropicService:
    def __init__(self):
        self.client = AsyncAnthropic(api_key=os.environ["ANTHROPIC_API_KEY"])

    def chat(self, message: str) -> StreamingResponse:
        messages = [{"role": "user", "content": message}]

        # Use Anthropic adapter
        adapter = AnthropicStreamAdapter(self.client)
        formatter = AISdkFormatter()
        streamer = LLMStreamer(adapter, formatter)

        return streamer.stream(messages)
```

### Adding a New Protocol Formatter

**Example: Server-Sent Events (SSE)**

```python
# app/core/streaming/formatters.py

class ServerSentEventsFormatter(ProtocolFormatter):
    """Formatter for Server-Sent Events protocol"""

    def format_text_chunk(self, content: str) -> str:
        """
        Format as SSE event

        SSE format:
        data: <json>

        """
        data = json.dumps({"type": "text", "content": content})
        return f"data: {data}\n\n"

    def format_finish_chunk(
        self,
        finish_reason: str,
        usage: Dict[str, int] | None = None
    ) -> str:
        """Format completion event"""
        data = json.dumps({
            "type": "finish",
            "finishReason": finish_reason,
            "usage": usage or {}
        })
        return f"data: {data}\n\n"

    def format_error_chunk(self, error: Exception) -> str:
        """Format error event"""
        data = json.dumps({
            "type": "error",
            "error": str(error),
            "errorType": error.__class__.__name__
        })
        return f"data: {data}\n\n"
```

**Usage:**

```python
# Use SSE formatter instead of AI SDK
from app.core.streaming.formatters import ServerSentEventsFormatter

adapter = OpenAIStreamAdapter(client, model="gpt-4o")
formatter = ServerSentEventsFormatter()  # Different formatter
streamer = LLMStreamer(adapter, formatter)

return streamer.stream(messages)
```

**Client-side SSE consumption:**

```javascript
const eventSource = new EventSource('/api/stream');

eventSource.onmessage = (event) => {
  const data = JSON.parse(event.data);

  if (data.type === 'text') {
    console.log('Content:', data.content);
  } else if (data.type === 'finish') {
    console.log('Done:', data.usage);
    eventSource.close();
  } else if (data.type === 'error') {
    console.error('Error:', data.error);
    eventSource.close();
  }
};
```

### Streaming Non-LLM Content

**Use Case:** Stream cached responses, static content, or pre-generated text

**Example:**

```python
# app/services/sample.py

def stream_story(self, chunk_size: int = 5) -> StreamingResponse:
    """Stream non-LLM text content"""
    story = "Once upon a time in a land far away..."

    # Use TextStreamer for non-LLM content
    return self.create_text_stream_response(
        text=story,
        chunk_size=chunk_size,
        prompt_tokens=0,
        completion_tokens=len(story)
    )
```

**Implementation:**

```python
# app/core/streaming/streamers/text.py

class TextStreamer:
    """Streamer for non-LLM text content"""

    def __init__(self, formatter: ProtocolFormatter | None = None):
        self.formatter = formatter or AISdkFormatter()

    async def _generate_stream(
        self,
        text: str,
        chunk_size: int,
        prompt_tokens: int,
        completion_tokens: int | None
    ) -> AsyncGenerator[str, None]:
        """Generate stream from text"""
        # Stream text in chunks
        for i in range(0, len(text), chunk_size):
            chunk = text[i:i + chunk_size]
            formatted = self.formatter.format_text_chunk(chunk)
            yield formatted

        # Send finish chunk
        usage = {
            "promptTokens": prompt_tokens,
            "completionTokens": completion_tokens or len(text)
        }
        formatted = self.formatter.format_finish_chunk("stop", usage)
        yield formatted

    def stream(
        self,
        text: str,
        chunk_size: int = 1,
        prompt_tokens: int = 0,
        completion_tokens: int | None = None
    ) -> StreamingResponse:
        """Create streaming response for text"""
        return StreamingResponse(
            self._generate_stream(
                text, chunk_size, prompt_tokens, completion_tokens
            ),
            media_type="text/event-stream",
            headers={
                "x-vercel-ai-data-stream": "v1",
                "Cache-Control": "no-cache",
                "Connection": "keep-alive"
            }
        )
```

## Client-Side Consumption

### Python Client

```python
import httpx
import json

async def consume_stream(city: str):
    """Consume AI SDK stream in Python"""
    async with httpx.AsyncClient() as client:
        async with client.stream(
            'POST',
            'http://localhost:8000/sample/city',
            json={"city": city, "model": "gpt-4o"},
            timeout=30.0
        ) as response:
            async for line in response.aiter_lines():
                if not line:
                    continue

                # Parse AI SDK protocol
                prefix, data = line.split(':', 1)

                if prefix == '0':  # Text chunk
                    content = json.loads(data)
                    print(content, end='', flush=True)

                elif prefix == 'e':  # End metadata
                    metadata = json.loads(data)
                    print(f"\n\nTokens: {metadata['usage']}")
                    print(f"Finish reason: {metadata['finishReason']}")

                elif prefix == '3':  # Error
                    error = json.loads(data)
                    print(f"\nError: {error['error']}")
                    break

# Run
import asyncio
asyncio.run(consume_stream("Paris"))
```

### JavaScript/TypeScript Client

```typescript
async function consumeStream(city: string) {
  const response = await fetch('http://localhost:8000/sample/city', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ city, model: 'gpt-4o' })
  });

  const reader = response.body!.getReader();
  const decoder = new TextDecoder();

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;

    const chunk = decoder.decode(value);
    const lines = chunk.split('\n');

    for (const line of lines) {
      if (!line) continue;

      const [prefix, data] = line.split(':', 2);

      if (prefix === '0') {
        // Text chunk
        const content = JSON.parse(data);
        process.stdout.write(content);
      } else if (prefix === 'e') {
        // End metadata
        const metadata = JSON.parse(data);
        console.log('\n\nTokens:', metadata.usage);
        console.log('Finish reason:', metadata.finishReason);
      } else if (prefix === '3') {
        // Error
        const error = JSON.parse(data);
        console.error('\nError:', error.error);
        break;
      }
    }
  }
}

// Run
consumeStream('Paris');
```

### Using Vercel AI SDK

```typescript
import { streamText } from 'ai';

const result = await streamText({
  model: yourModel,
  prompt: 'Tell me about Paris',
});

// The AI SDK handles the protocol automatically
for await (const chunk of result.textStream) {
  process.stdout.write(chunk);
}

console.log('Usage:', result.usage);
```

## Testing Streaming

### Unit Testing Adapters

```python
# tests/test_openai_adapter.py

import pytest
from app.core.streaming.adapters.openai import OpenAIStreamAdapter
from app.core.streaming.base import StreamChunk

@pytest.mark.asyncio
async def test_adapter_yields_content_chunks():
    """Test adapter converts OpenAI chunks to StreamChunks"""

    # Mock OpenAI client
    class MockStream:
        async def __aiter__(self):
            # Yield mock OpenAI chunks
            yield MockChunk(content="Hello")
            yield MockChunk(content=" world")
            yield MockChunk(finish_reason="stop")

    class MockClient:
        class chat:
            class completions:
                @staticmethod
                async def create(**kwargs):
                    return MockStream()

    # Test adapter
    adapter = OpenAIStreamAdapter(MockClient(), model="gpt-4o")
    chunks = []

    async for chunk in adapter.stream([{"role": "user", "content": "Hi"}]):
        chunks.append(chunk)

    # Verify
    assert len(chunks) == 3
    assert chunks[0].content == "Hello"
    assert chunks[1].content == " world"
    assert chunks[2].finish_reason == "stop"
```

### Unit Testing Formatters

```python
# tests/test_formatters.py

from app.core.streaming.formatters import AISdkFormatter

def test_formatter_formats_text_chunk():
    formatter = AISdkFormatter()
    result = formatter.format_text_chunk("hello")

    assert result == '0:"hello"\n'
    assert result.startswith('0:')

def test_formatter_formats_finish_chunk():
    formatter = AISdkFormatter()
    result = formatter.format_finish_chunk(
        "stop",
        usage={"promptTokens": 10, "completionTokens": 20}
    )

    assert result.startswith('e:')
    assert '"finishReason": "stop"' in result
    assert '"promptTokens": 10' in result

def test_formatter_formats_error_chunk():
    formatter = AISdkFormatter()
    result = formatter.format_error_chunk(ValueError("bad input"))

    assert result.startswith('3:')
    assert '"error": "bad input"' in result
    assert '"type": "ValueError"' in result
```

### Integration Testing Services

```python
# tests/test_sample_service.py

def test_service_creates_stream(monkeypatch):
    """Test service creates streaming response"""

    # Mock environment
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")

    # Capture streamer call
    captured = {}

    class MockStreamer:
        def stream(self, messages, **kwargs):
            captured["messages"] = messages
            captured["kwargs"] = kwargs
            return "streaming-response"

    # Inject mocks
    monkeypatch.setattr(module, "LLMStreamer", lambda a, f: MockStreamer())

    # Test
    service = SampleStreamingService()
    result = service.ask_about_city("Paris", model="gpt-4o")

    # Verify
    assert result == "streaming-response"
    assert "Paris" in captured["messages"][1]["content"]
```

### End-to-End Testing

```python
# tests/test_sample_router.py

from fastapi.testclient import TestClient

def test_city_endpoint_streams_response():
    """Test complete streaming flow"""
    client = TestClient(app)

    # Make request
    with client.stream(
        "POST",
        "/sample/city",
        json={"city": "Paris", "model": "gpt-4o"}
    ) as response:
        # Verify headers
        assert response.headers["x-vercel-ai-data-stream"] == "v1"
        assert response.headers["content-type"] == "text/event-stream"

        # Collect chunks
        chunks = []
        for line in response.iter_lines():
            if line:
                chunks.append(line)

        # Verify protocol
        assert any(chunk.startswith("0:") for chunk in chunks)  # Text
        assert any(chunk.startswith("e:") for chunk in chunks)  # End
```

## Performance Considerations

### Buffer Size

Control chunk sizes for optimal performance:

```python
# Small chunks - more responsive, more overhead
return self.create_text_stream_response(text, chunk_size=1)

# Large chunks - less responsive, less overhead
return self.create_text_stream_response(text, chunk_size=100)
```

### Timeout Handling

Set appropriate timeouts:

```python
# Client-side
async with httpx.AsyncClient(timeout=30.0) as client:
    async with client.stream(...) as response:
        async for line in response.aiter_lines():
            pass

# Server-side (if needed)
from fastapi import Request

@router.post("/stream")
async def stream_endpoint(request: Request):
    # Check if client disconnected
    if await request.is_disconnected():
        return
```

### Error Recovery

Handle streaming errors gracefully:

```python
class LLMStreamer:
    async def _generate_stream(self, messages, **kwargs):
        try:
            async for chunk in self.adapter.stream(messages, **kwargs):
                yield self.formatter.format_text_chunk(chunk.content)

        except Exception as e:
            # Send error chunk instead of crashing
            error_chunk = self.formatter.format_error_chunk(e)
            yield error_chunk
```

## Troubleshooting

### Common Issues

**Issue: Stream hangs or doesn't start**

```python
# Check: Are you awaiting async functions?
# ❌ Bad
def service_method(self):
    self.client.chat.completions.create()  # Missing await

# ✅ Good
async def service_method(self):
    await self.client.chat.completions.create()
```

**Issue: Chunks not appearing in order**

```python
# Check: Are you buffering correctly?
# The formatter should add newlines
def format_text_chunk(self, content):
    return f'0:{json.dumps(content)}\n'  # ← Newline important!
```

**Issue: Client can't parse response**

```python
# Check: Headers set correctly?
response.headers["x-vercel-ai-data-stream"] = "v1"
response.headers["Content-Type"] = "text/event-stream"
```

## Summary

### Key Concepts

1. **StreamChunk**: Normalized data format
2. **StreamAdapter**: Provider-specific LLM integration
3. **ProtocolFormatter**: Output format (AI SDK, SSE, etc.)
4. **LLMStreamer**: Orchestrates streaming
5. **BaseStreamingService**: Convenient helper for services

### Extension Points

- **New Provider**: Implement `StreamAdapter`
- **New Format**: Implement `ProtocolFormatter`
- **Custom Logic**: Extend `BaseStreamingService`
- **Non-LLM Content**: Use `TextStreamer`

### Best Practices

✅ **Do:**
- Use `BaseStreamingService` for convenience
- Test adapters and formatters independently
- Handle errors within streams
- Set appropriate timeouts
- Document custom adapters/formatters

❌ **Don't:**
- Block async streams with sync code
- Skip error handling in streams
- Hardcode provider details in services
- Mix streaming logic with business logic

---

**Next:** [Testing Guide](./05-testing.md) - Learn how to test your code
