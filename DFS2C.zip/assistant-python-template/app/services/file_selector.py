import json
import os

from fastapi.responses import StreamingResponse
from openai import AsyncOpenAI

from app.errors import IncorrectAPIInvocationError
from app.services.base import BaseStreamingService
from app.templates.builder import PromptBuilder


def build_file_selector_prompt(directory_structure: dict) -> str:
    """
    Build a prompt that instructs the LLM to select relevant files and suggest line counts for them.
    """

    if not directory_structure:
        raise IncorrectAPIInvocationError(
            msg="Directory structure must not be empty"
        )

    prompt = (
        PromptBuilder("file_selector_prompt.j2")
        .var("directory_structure", json.dumps(directory_structure, indent=2))
        .build()
    )

    return prompt

class FileSelectionStreamingService(BaseStreamingService):
    """
    An LLM-powered service for determining file selection and line limits.
    """

    def __init__(self):
        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY environment variable is required")

        self.client = AsyncOpenAI(api_key=api_key)

    def suggest_files_to_read(
        self,
        directory_structure: dict,
        model: str = "gpt-4o",
    ) -> StreamingResponse:
        """
        Stream file selection suggestions from the LLM.

        The LLM is expected to return structured JSON:
        [
          {
            "file_path": "train/text_files/file.txt",
            "lines_to_read": 100,
            "reason": "Contains training examples"
          }
        ]
        """

        prompt = build_file_selector_prompt(directory_structure)

        messages = [
            {
                "role": "system",
                "content": (
                    "You are a data engineer. "
                    "Analyze the directory structure and suggest which files "
                    "should be read and how many lines from each. "
                    "Always respond in valid JSON."
                ),
            },
            {"role": "user", "content": prompt},
        ]

        return self.create_stream_response(
            client=self.client,
            messages=messages,
            model=model,
        )
