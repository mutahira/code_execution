# Rules and Documentation

This folder contains comprehensive documentation for junior developers and contributors to understand and work with this FastAPI assistant template.

## 📚 Documentation Structure

### [00-overview.md](./00-overview.md)
**Start here!** Get the big picture of the project.

- Project purpose and goals
- Tech stack overview
- Quick start guide
- Key features and concepts
- Project structure explanation
- Core architectural patterns

**Read this first** to understand what the project does and how to get it running.

### [01-file-structure.md](./01-file-structure.md)
**Where does everything go?**

- Directory layout and organization
- File naming conventions
- What each folder contains
- When to create new files
- Import organization
- Path references

**Read this** when you need to add new files or understand where to find things.

### [02-naming-conventions.md](./02-naming-conventions.md)
**How should I name things?**

- Python naming standards
- Class, function, and variable naming
- FastAPI-specific conventions
- Pydantic model naming
- Route and endpoint naming
- Test naming patterns
- Common abbreviations to avoid

**Reference this** when naming any new classes, functions, files, or variables.

### [03-architecture.md](./03-architecture.md)
**How does everything work together?**

- Layered architecture explained
- Design patterns used
- Request flow diagrams
- Component interactions
- Error handling patterns
- Configuration patterns
- Dependency injection
- Best practices

**Study this** to understand the design patterns and how components interact.

### [04-streaming.md](./04-streaming.md)
**How does streaming work?**

- Streaming infrastructure architecture
- Component responsibilities
- AI SDK protocol format
- Data flow diagrams
- Adding new LLM providers
- Adding new output formats
- Testing streaming code
- Client-side consumption examples

**Deep dive here** when working with streaming features or adding LLM integrations.

### [05-testing.md](./05-testing.md)
**How do I test my code?**

- Testing philosophy and pyramid
- Test organization
- Running tests with pytest
- Unit testing patterns
- Integration testing
- Mocking and fixtures
- Testing async code
- Code coverage
- Best practices

**Consult this** when writing tests or debugging test failures.

## 🚀 Getting Started Path

### For Complete Beginners

1. **Start**: [00-overview.md](./00-overview.md)
   - Understand what the project does
   - Follow the quick start guide
   - Get the application running locally

2. **Next**: [01-file-structure.md](./01-file-structure.md)
   - Learn where files are located
   - Understand the folder structure
   - Know where to add new code

3. **Then**: [02-naming-conventions.md](./02-naming-conventions.md)
   - Learn how to name things consistently
   - Follow established patterns
   - Write idiomatic code

4. **Study**: [03-architecture.md](./03-architecture.md)
   - Understand how components connect
   - Learn the design patterns
   - See how data flows through the system

5. **Dive Deep**: [04-streaming.md](./04-streaming.md) (if working with streaming)
   - Master the streaming infrastructure
   - Learn to add new providers
   - Understand the protocols

6. **Practice**: [05-testing.md](./05-testing.md)
   - Write tests for your code
   - Run and debug tests
   - Achieve good coverage

### For Experienced Developers

**Quick Reference Order:**

1. [00-overview.md](./00-overview.md) - Get context (15 min read)
2. [01-file-structure.md](./01-file-structure.md) - Find things fast (10 min read)
3. [03-architecture.md](./03-architecture.md) - Understand patterns (20 min read)
4. [04-streaming.md](./04-streaming.md) - If using streaming (30 min read)
5. Keep [02-naming-conventions.md](./02-naming-conventions.md) and [05-testing.md](./05-testing.md) as references

## 🎯 Task-Based Navigation

### I want to...

#### Add a new HTTP endpoint
1. Read: [01-file-structure.md - Routers Directory](./01-file-structure.md#routers-directory-approuters)
2. Reference: [02-naming-conventions.md - Route Endpoint Names](./02-naming-conventions.md#route-endpoint-names)
3. Follow: [03-architecture.md - HTTP Layer](./03-architecture.md#1-http-layer-approuters)
4. Test: [05-testing.md - Testing Routers](./05-testing.md#5-testing-routers)

#### Add business logic
1. Read: [01-file-structure.md - Services Directory](./01-file-structure.md#services-directory-appservices)
2. Reference: [02-naming-conventions.md - Service Class Naming](./02-naming-conventions.md#service-class-naming)
3. Follow: [03-architecture.md - Business Logic Layer](./03-architecture.md#2-business-logic-layer-appservices)
4. Test: [05-testing.md - Unit Testing Classes](./05-testing.md#2-unit-testing-classes)

#### Add LLM streaming
1. Study: [04-streaming.md - Overview](./04-streaming.md#overview)
2. Follow: [04-streaming.md - Data Flow](./04-streaming.md#data-flow)
3. Reference: [04-streaming.md - BaseStreamingService](./04-streaming.md#5-basestreamingservice-helper-base-class)
4. Test: [05-testing.md - Testing Streaming Endpoints](./05-testing.md#6-testing-streaming-endpoints)

#### Add a new LLM provider
1. Study: [04-streaming.md - StreamAdapter](./04-streaming.md#2-streamadapter-abstract-base-class)
2. Follow: [04-streaming.md - Adding a New LLM Provider Adapter](./04-streaming.md#adding-a-new-llm-provider-adapter)
3. Reference: [02-naming-conventions.md - Adapter Class Names](./02-naming-conventions.md#adapter-class-names)
4. Test: [05-testing.md - Testing Adapters](./05-testing.md#9-testing-adapters)

#### Create data models
1. Read: [01-file-structure.md - Models Directory](./01-file-structure.md#models-directory-appmodels)
2. Reference: [02-naming-conventions.md - Model Class Names](./02-naming-conventions.md#model-class-names)
3. Follow: [03-architecture.md - Data Layer](./03-architecture.md#4-data-layer-appmodels)
4. Test: [05-testing.md - Testing Pydantic Models](./05-testing.md#7-testing-pydantic-models)

#### Write tests
1. Start: [05-testing.md - Overview](./05-testing.md#overview)
2. Follow: [05-testing.md - Test Structure](./05-testing.md#test-structure)
3. Reference: [05-testing.md - Testing Patterns](./05-testing.md#testing-patterns)
4. Run: [05-testing.md - Running Tests](./05-testing.md#running-tests)

#### Debug issues
1. Logs: [03-architecture.md - Logging Pattern](./03-architecture.md#logging-pattern)
2. Tests: [05-testing.md - Debugging Tests](./05-testing.md#debugging-tests)
3. Streaming: [04-streaming.md - Troubleshooting](./04-streaming.md#troubleshooting)
4. Errors: [03-architecture.md - Error Handling Patterns](./03-architecture.md#error-handling-patterns)

## 📖 Learning Resources

### Code Examples

Each documentation file includes:
- ✅ **Good examples** - Follow these patterns
- ❌ **Bad examples** - Avoid these anti-patterns
- Real code snippets from the project
- Template code you can copy and adapt

### Visual Aids

- Architecture diagrams
- Data flow charts
- Component relationships
- Request/response flows

### Quick Reference Tables

- File naming conventions
- Class/function naming patterns
- Test command cheatsheets
- Protocol specifications

## 🔍 Search Tips

### Finding Information

**By Keyword:**
- Use your editor's search (Ctrl+F / Cmd+F) to find terms across all docs
- Search for code patterns you've seen elsewhere
- Look for error messages you're encountering

**By Pattern:**
```bash
# Search all documentation files
grep -r "keyword" rules/*.md

# Find examples of a pattern
grep -r "class.*Service" rules/*.md

# Find test examples
grep -r "def test_" rules/*.md
```

**By Topic:**
- Routing → [01-file-structure.md](./01-file-structure.md) + [03-architecture.md](./03-architecture.md)
- Naming → [02-naming-conventions.md](./02-naming-conventions.md)
- Streaming → [04-streaming.md](./04-streaming.md)
- Testing → [05-testing.md](./05-testing.md)

## 🤝 Contributing

### Updating Documentation

When you add new features:

1. **Update relevant docs** - Keep documentation in sync with code
2. **Add examples** - Show how to use the new feature
3. **Update diagrams** - If architecture changes
4. **Add to this README** - If it's a new pattern

### Documentation Style

- Use clear, simple language
- Include code examples
- Show both good and bad patterns
- Keep it practical and actionable
- Update regularly

## ⚡ Quick Links

### External Resources

- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [Pydantic Documentation](https://docs.pydantic.dev/)
- [Pytest Documentation](https://docs.pytest.org/)
- [OpenAI API Documentation](https://platform.openai.com/docs/)
- [AI SDK Documentation](https://sdk.vercel.ai/docs)

### Project Files

- [Main README](../README.md)
- [Streaming Documentation](../STREAMING.md)
- [Project Configuration](../pyproject.toml)
- [OpenAPI Spec](../openapi.json)

## 📝 Feedback

Found something unclear? Have suggestions?

- Open an issue in the project repository
- Submit a pull request with improvements
- Ask questions in team channels
- Update these docs as you learn

---

**Remember:** These docs are living documents. Update them as the project evolves and you discover better patterns!

---

## Document Versions

| Document | Last Updated | Version |
|----------|-------------|---------|
| 00-overview.md | 2025-10-14 | 1.0 |
| 01-file-structure.md | 2025-10-14 | 1.0 |
| 02-naming-conventions.md | 2025-10-14 | 1.0 |
| 03-architecture.md | 2025-10-14 | 1.0 |
| 04-streaming.md | 2025-10-14 | 1.0 |
| 05-testing.md | 2025-10-14 | 1.0 |

**Comprehensive documentation created for junior developers to understand and contribute to the FastAPI assistant template project.**
