from fastapi import HTTPException


class IncorrectAPIInvocationError(HTTPException):
    """Raised when the API is invoked incorrectly"""

    def __init__(self, msg: str):
        super().__init__(status_code=400, detail=msg)
