from pydantic_settings import BaseSettings
from pydantic import ConfigDict
from pathlib import Path


class Settings(BaseSettings):
    GITHUB_APP_ID: int
    GITHUB_PRIVATE_KEY_PATH: str

    model_config = ConfigDict(
        env_file=".env",
        extra="ignore"
    )

    @property
    def GITHUB_PRIVATE_KEY(self) -> str:
        key_path = Path(self.GITHUB_PRIVATE_KEY_PATH)

        if not key_path.exists():
            raise FileNotFoundError(
                f"GitHub private key not found at {key_path}"
            )

        return key_path.read_text()


settings = Settings()

