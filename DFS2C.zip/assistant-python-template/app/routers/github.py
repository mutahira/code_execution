from fastapi import APIRouter
from fastapi.responses import RedirectResponse
from os import getenv
from fastapi import Query
from app.github.store import INSTALLATIONS
from app.services.github_service import GitHubService
from fastapi import APIRouter, HTTPException
from app.services.github_repos import list_repositories
from app.models.github_repos import GitHubRepo
from fastapi import Depends
from fastapi.responses import RedirectResponse
from app.github.keycloak_auth import get_current_user
from app.github.pocketbase_client import pb_admin
from jose import jwt
import requests
from fastapi.responses import JSONResponse

router = APIRouter(prefix="/github", tags=["GitHub"])

# TEMP: single-user memory storage
#INSTALLATIONS = {}
from uuid import uuid4

from app.github.store import INSTALL_STATES

@router.post("/install/start")
def start_install(
    payload: dict,
    user_id: str = Depends(get_current_user)
):
    return_url = payload["return_url"]

    state = str(uuid4())

    INSTALL_STATES[state] = {
        "user_id": user_id,
        "return_url": return_url,
    }

    install_url = (
        f"https://github.com/apps/DataAnalysisAssistant/installations/new"
        f"?state={state}"
    )

    return {"install_url": install_url}




@router.get("/install")
def github_install():
    return RedirectResponse(
        "https://github.com/apps/DataAnalysisAssistant/installations/new",
        status_code=302
    )


@router.get("/callback")
def github_callback(
    installation_id: int,
    state: str
):
    data = INSTALL_STATES.pop(state, None)

    if not data:
        raise HTTPException(400, "Invalid state")

    user_id = data["user_id"]
    return_url = data["return_url"]

    records = pb_admin.collection("github_installations").get_list(
    page=1,
    per_page=1,
    query_params={
        "filter": f'user_id="{user_id}"'
    }
)


    if records.items:
        pb_admin.collection("github_installations").update(
            records.items[0].id,
            {"installation_id": installation_id}
        )
    else:
        pb_admin.collection("github_installations").create({
            "user_id": user_id,
            "installation_id": installation_id,
        })

    return RedirectResponse(return_url)


@router.post("/link-installation")
def link_installation(user_id: str = Depends(get_current_user)):
    records = pb_admin.collection("github_installations").get_list(
        filter='user_id = null',
        sort='-created'
    )

    if not records.items:
        raise HTTPException(400, "No pending GitHub installation")

    installation = records.items[0]

    pb_admin.collection("github_installations").update(
        installation.id,
        {"user_id": user_id}
    )

    return {"status": "linked"}




#New router for github repos

@router.get("/repos")
def list_repos(user_id: str = Depends(get_current_user)):
    records = pb_admin.collection("github_installations").get_list(
    page=1,
    per_page=1,
    query_params={
        "filter": f'user_id="{user_id}"'
    }
)


    if not records.items:
        raise HTTPException(400, "GitHub not connected")

    installation_id = records.items[0].installation_id
    
    return list_repositories(installation_id)

    # call GitHub API with installation_id

