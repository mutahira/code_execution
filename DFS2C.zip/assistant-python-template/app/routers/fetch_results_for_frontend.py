from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Any
import uuid
import base64

from app.github.pocketbase_client import pb_admin
from app.github.auth2 import get_installation_token
import requests
from app.models.fetch_results_for_frontend import FetchResultRequest
from app.services.github_results import upload_to_github
from fastapi import APIRouter, Depends


router = APIRouter(prefix="/results", tags=["notebooks"])

@router.post("/frontend/fetch")
def fetch_result(payload: FetchResultRequest):
    try:
        # 1️⃣ Find result record by user_id + itemId
        record = pb_admin.collection("result_record").get_first_list_item(
            f'user_id="{payload.user_id}" && itemId="{payload.itemId}"'
        )

        if not record:
            raise HTTPException(status_code=404, detail="Result record not found")

        # 2️⃣ Check status
        if record.status == "waiting":
            return {"status": "waiting", "message": "results are not being uploaded"}

        if record.status != "uploaded":
            raise HTTPException(status_code=400, detail="Invalid result status")

        # 3️⃣ Get GitHub installation
        installation_record = pb_admin.collection("github_installations").get_first_list_item(
            f'user_id="{payload.user_id}"'
        )

        if not installation_record:
            raise HTTPException(status_code=400, detail="GitHub installation not found")

        installation_id = installation_record.installation_id

        # 4️⃣ Get GitHub token
        token = get_installation_token(int(installation_id))

        owner = record.github_owner
        repo = record.github_repo
        branch = getattr(record, "branch", "main")
        dataset_folder = record.folder_name
        filename = record.output

        path = f"{dataset_folder}/{filename}"

        # 5️⃣ Fetch file from GitHub
        url = f"https://api.github.com/repos/{owner}/{repo}/contents/{path}"

        response = requests.get(
            url,
            headers={
                "Authorization": f"token {token}",
                "Accept": "application/vnd.github+json"
            },
            params={"ref": branch}
        )
        print("GitHub API response status:", response.status_code)

        response.raise_for_status()

        file_data = response.json()

        # GitHub returns base64 content
        content_base64 = file_data["content"]
        decoded_content = base64.b64decode(content_base64).decode(errors="ignore")

        return {
    "status": "success",
    "filename": filename,
    "encoding": "base64",
    "content": file_data["content"]
}

    except Exception as e:
        print("ERROR:", e)
        raise HTTPException(status_code=400, detail=str(e))