import jwt
import time
import requests

from dotenv import load_dotenv
import os

load_dotenv()
GITHUB_APP_ID = os.getenv("GITHUB_APP_ID")
GITHUB_PRIVATE_KEY_PATH = os.getenv("GITHUB_PRIVATE_KEY_PATH")
with open(GITHUB_PRIVATE_KEY_PATH, "r") as f:
     private_key = f.read()

def get_installation_token(installation_id: int) -> str:
    payload = {
        "iat": int(time.time()) - 60,
        "exp": int(time.time()) + 600,
        "iss": GITHUB_APP_ID,
    }

    jwt_token = jwt.encode(payload, private_key, algorithm="RS256")

    response = requests.post(
        f"https://api.github.com/app/installations/{installation_id}/access_tokens",
        headers={
            "Authorization": f"Bearer {jwt_token}",
            "Accept": "application/vnd.github+json",
        },
    )

    response.raise_for_status()
    return response.json()["token"]
