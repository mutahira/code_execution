import http
import logging
from pathlib import Path

from fastapi import APIRouter
from app.models.dataset_directory_reader import ReadDirectoryRequest, ReadDirectoryResponse
from app.services.dataset_directory_reader import read_directory_with_fuzzy_matching

#See in future to do the logging at the higher level (e.x. main.py) and pass the logger to the services and routers, instead of configuring it here. This way we can have a more centralized logging configuration and avoid potential issues with multiple loggers being configured in different parts of the application.
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

router = APIRouter(prefix="/dataset/directory", tags=["Dataset Directory Reader"])


@router.post(
    "/reader",
    status_code=http.HTTPStatus.OK,
    response_model=ReadDirectoryResponse,
)
def read_directory(request: ReadDirectoryRequest):
    """
    Recursively read a directory and apply fuzzy grouping to files where needed.
    """
    path = Path(request.path)

    if not path.exists():
        return ReadDirectoryResponse(success=False, structure=None, error_message=f"Path '{path}' does not exist") 
    try:
        structure = read_directory_with_fuzzy_matching(path)
        return ReadDirectoryResponse(success=True, structure=structure)
    except PermissionError as e:
        logger.warning(str(e))
        return ReadDirectoryResponse(success=False, structure=None, error_message=str(e))
    except Exception as e:
        logger.exception("Failed to read directory structure")
        return ReadDirectoryResponse(success=False, structure=None, error_message=str(e))
