from typing import Any, Dict, List

from fastapi.responses import StreamingResponse
from openai import AsyncOpenAI

from app.core.streaming.adapters.openai import OpenAIStreamAdapter
from app.core.streaming.formatters import AISdkFormatter
from app.core.streaming.streamers.llm import LLMStreamer
from app.core.streaming.streamers.text import TextStreamer


class BaseStreamingService:
    """
    Base service class that provides streaming capabilities.

    Services that need to stream LLM responses can inherit from this class
    and use the create_stream_response method to easily create streaming responses.
    """

    def create_stream_response(
        self,
        client: AsyncOpenAI,
        messages: List[Dict[str, Any]],
        model: str = "gpt-4o",
        **kwargs,
    ) -> StreamingResponse:
        """
        Create a streaming response using OpenAI and AI SDK protocol.

        :param client: AsyncOpenAI client instance
        :param messages: List of message dictionaries in OpenAI format
        :param model: Model name to use (default: gpt-4o)
        :param kwargs: Additional parameters for the OpenAI API
        :return: FastAPI StreamingResponse ready to be returned from a route
        """
        # Create adapter and formatter
        adapter = OpenAIStreamAdapter(client, model=model)
        formatter = AISdkFormatter()

        # Create streamer and return response
        streamer = LLMStreamer(adapter, formatter)
        return streamer.stream(messages, **kwargs)

    def create_text_stream_response(
        self,
        text: str,
        chunk_size: int = 1,
        prompt_tokens: int = 0,
        completion_tokens: int | None = None,
    ) -> StreamingResponse:
        """
        Create a streaming response for non-LLM text content.

        This method streams plain text in chunks using the AI SDK protocol,
        making it compatible with the same client-side handling as LLM streams.

        :param text: The text to stream
        :param chunk_size: Number of characters per chunk (default: 1 for character-by-character)
        :param prompt_tokens: Number of prompt tokens to report in usage (default: 0)
        :param completion_tokens: Number of completion tokens to report (default: length of text)
        :return: FastAPI StreamingResponse ready to be returned from a route
        """
        streamer = TextStreamer()
        return streamer.stream(text, chunk_size, prompt_tokens, completion_tokens)
