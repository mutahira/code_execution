from pathlib import Path
from typing import Union, Dict, Any, List, Optional
from app.directory_reader.fuzzy_grouper import fuzzy_group_files


def read_directory_with_fuzzy_matching(
    path: Union[str, Path],
    include_hidden: bool = False,
    fuzzy_threshold: int = 50,
    max_depth: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Recursively scan directories, apply fuzzy grouping to files if needed,
    and return a hierarchical structure.
    """

    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Path '{path}' does not exist")
    if path == Path("/"):
        raise PermissionError("Refusing to scan root directory '/'")

    def process_dir(p: Path, depth: int = 0) -> Dict[str, Any]:
        if max_depth is not None and depth > max_depth:
            return {
                "name": p.name,
                "type": "directory",
                "files_count": 0,
                "sample_files": [],
                "children": [],
            }

        if not include_hidden and p.name.startswith("."):
            return {}

        # Directory
        dir_node: Dict[str, Any] = {
            "name": p.name,
            "type": "directory",
            "files_count": 0,
            "sample_files": [],
            "children": []
        }

        # Files in directory
        files_in_dir = [f for f in p.iterdir() if f.is_file()]
        if not include_hidden:
            files_in_dir = [f for f in files_in_dir if not f.name.startswith(".")]

        dir_node["files_count"] = len(files_in_dir)

        # Apply fuzzy logic if enough files
        if len(files_in_dir) >= fuzzy_threshold:
            file_nodes = [{"name": f.name} for f in files_in_dir]
            fuzzy_groups = fuzzy_group_files(file_nodes)
            # Take a few sample filenames from all groups
            samples = []
            for g in fuzzy_groups:
                samples.extend(g.get("sample_files", []))
            dir_node["sample_files"] = samples[:30]  # Max 30 sample files
        else:
            # Few files, just take first few
            dir_node["sample_files"] = [f.name for f in files_in_dir[:30]]

        # Process subdirectories
        for child in p.iterdir():
            if child.is_dir():
                child_node = process_dir(child, depth + 1)
                if child_node:
                    dir_node["children"].append(child_node)

        return dir_node

    return process_dir(path)
