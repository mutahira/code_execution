from app.errors import IncorrectAPIInvocationError


def test_incorrect_api_invocation_error_sets_status_and_detail():
    error = IncorrectAPIInvocationError("Invalid call")

    assert error.status_code == 400
    assert error.detail == "Invalid call"
