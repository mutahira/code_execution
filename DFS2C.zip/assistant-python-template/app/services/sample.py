import os

from fastapi.responses import StreamingResponse
from openai import AsyncOpenAI

from app.errors import IncorrectAPIInvocationError
from app.services.base import BaseStreamingService
from app.templates.builder import PromptBuilder


def get_prompt(city: str) -> str:
    if "error" in city.lower():
        raise IncorrectAPIInvocationError(
            msg="The city name contains an invalid word: 'error'"
        )

    prompt = PromptBuilder("prompt.j2").var("city", city).build()

    return prompt


class SampleStreamingService(BaseStreamingService):
    """
    Sample service demonstrating streaming functionality

    This service shows how to extend BaseStreamingService and use
    the streaming infrastructure in your own services.
    """

    def __init__(self):
        """Initialize the service with an OpenAI client."""
        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY environment variable is required")

        self.client = AsyncOpenAI(api_key=api_key)

    def ask_about_city(self, city: str, model: str = "gpt-4o") -> StreamingResponse:
        """
        Stream information about a city using the LLM.

        This demonstrates how services can orchestrate LLM calls!

        :param city: The city name to ask about
        :param model: The model to use (default: gpt-4o)

        :return: StreamingResponse with the LLM's response in AI SDK format
        """

        messages = [
            {"role": "system", "content": "Follow the user's instructions carefully."},
            {"role": "user", "content": get_prompt(city)},
        ]

        # Use the streaming infrastructure to stream the response
        return self.create_stream_response(
            client=self.client, messages=messages, model=model
        )

    def stream_story(self, chunk_size: int = 5) -> StreamingResponse:
        """
        Stream a predefined story as non-LLM content.

        This demonstrates how to stream plain text content without using an LLM,
        useful for streaming static content, cached responses, or pre-generated text.

        :param chunk_size: Number of characters to stream per chunk (default: 5)
        :return: StreamingResponse with the story in AI SDK format
        """
        story = "Here is a story about a brave knight who ventured into the unknown lands seeking adventure and glory."

        # Stream the text with custom token counts
        # You can set prompt_tokens and completion_tokens to any values you want
        return self.create_text_stream_response(
            text=story,
            chunk_size=chunk_size,
            prompt_tokens=0,
            completion_tokens=len(story),  # or any predefined number
        )
