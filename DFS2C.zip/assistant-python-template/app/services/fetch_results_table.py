import requests
from typing import Optional
from app.github.pocketbase_client import pb_admin

POCKETBASE_URL = "http://127.0.0.1:8090"  # change if needed


def create_execution_record(
    user_id: str,
    github_owner: str,
    github_repo: str,
    branch: str,
    itemId: Optional[str],
    datasetFolder: Optional[str] = None,
):
    """
    Creates a new execution record in PocketBase
    """

    data = {
        "user_id": user_id,
        "github_owner": github_owner,
        "github_repo": github_repo,
        "branch": branch,
        "itemId": itemId,
        "status": "waiting",
        "datasetFolder": datasetFolder,
    }

    #response = requests.post(
     #   f"{POCKETBASE_URL}/api/collections/result_record/records",
      #  json=data,
    #)
    record = pb_admin.collection("result_record").create(data)

    #response.raise_for_status()

    return record