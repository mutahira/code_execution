# Project Overview

## Introduction

This is a **FastAPI-based assistant template** designed to help you quickly build AI-powered assistants with streaming capabilities. The template follows clean architecture principles, making it easy to understand, extend, and maintain.

## Purpose

The template provides:

- 🚀 **Ready-to-use FastAPI application** with modern Python practices
- 🌊 **Streaming infrastructure** for real-time LLM responses (OpenAI, etc.)
- 📦 **Modular architecture** with clear separation of concerns
- 🧪 **Comprehensive testing** setup with pytest
- 🎨 **Interactive demos** to test endpoints
- 📝 **Template system** for building prompts

## Target Audience

This template is designed for:

- Junior developers learning FastAPI and LLM integration
- Teams building AI assistants and chatbots
- Developers who need streaming LLM responses
- Anyone looking for a clean, production-ready starting point

## Tech Stack

### Core Technologies

- **Python 3.11+**: Modern Python with type hints
- **FastAPI**: High-performance async web framework
- **Pydantic v2**: Data validation using Python type annotations
- **Jinja2**: Template engine for prompts
- **OpenAI SDK**: LLM integration (extensible to other providers)

### Development Tools

- **Poetry**: Dependency management
- **pytest**: Testing framework with async support
- **pytest-cov**: Code coverage reporting
- **black**: Code formatting
- **isort**: Import sorting
- **flake8**: Linting
- **uvicorn**: ASGI server

## Key Features

### 1. Streaming Infrastructure

The template includes a complete streaming infrastructure that:

- Streams LLM responses in real-time using the AI SDK protocol
- Supports multiple LLM providers through adapters
- Handles errors gracefully during streaming
- Works with both LLM and non-LLM content

### 2. Clean Architecture

```
app/
├── routers/        # HTTP endpoints (FastAPI routes)
├── services/       # Business logic layer
├── models/         # Pydantic data models
├── core/           # Core utilities (decorators, streaming)
├── templates/      # Jinja2 templates for prompts
└── static/         # HTML demos and static files
```

### 3. Developer Experience

- **Hot reload**: Changes reflect immediately during development
- **Interactive demos**: Test streaming in your browser
- **Comprehensive tests**: Learn by example from test files
- **Type hints**: Full type safety throughout the codebase
- **Debug logging**: Request/response logging with decorators

## Quick Start

### Prerequisites

```bash
# Python 3.11 or higher
python --version

# Poetry (recommended) or pip
poetry --version
```

### Installation

```bash
# Clone the repository
cd assistant-python-template

# Install dependencies (Poetry)
poetry install
```

### Configuration

```bash
# Set your OpenAI API key
export OPENAI_API_KEY="your-api-key-here"
```

### Run the Application

```bash
# With Poetry
poetry run uvicorn app.main:app --reload

# OR with pip installation
uvicorn app.main:app --reload
```

### Access the Application

- **API**: http://localhost:8000
- **Docs**: http://localhost:8000/docs
- **Demo**: http://localhost:8000/static/streaming-demo.html

## Project Structure

```
assistant-python-template/
├── app/                        # Main application code
│   ├── main.py                # Application entry point
│   ├── app_factory.py         # App configuration and setup
│   ├── errors.py              # Custom exceptions
│   ├── routers/               # API route handlers
│   │   └── sample.py
│   ├── services/              # Business logic
│   │   ├── base.py           # Base service classes
│   │   └── sample.py         # Example services
│   ├── models/                # Pydantic models
│   │   └── sample.py
│   ├── core/                  # Core utilities
│   │   ├── decorators.py     # Logging decorators
│   │   └── streaming/        # Streaming infrastructure
│   │       ├── base.py       # Abstract classes
│   │       ├── formatters.py # Protocol formatters
│   │       ├── adapters/     # LLM adapters
│   │       │   └── openai.py
│   │       └── streamers/    # Stream orchestrators
│   │           ├── llm.py
│   │           └── text.py
│   ├── templates/             # Prompt templates
│   │   ├── builder.py        # Template builder
│   │   └── j2/               # Jinja2 templates
│   │       └── prompt.j2
│   └── static/                # Static files & demos
│       ├── index.html
│       └── streaming-demo.html
├── tests/                     # Test suite
│   ├── conftest.py           # Pytest configuration
│   ├── test_*.py             # Test modules
│   └── __pycache__/
├── rules/                     # Documentation (this folder)
│   ├── 00-overview.md        # This file
│   ├── 01-file-structure.md  # File organization
│   ├── 02-naming-conventions.md
│   ├── 03-architecture.md
│   ├── 04-streaming.md
│   └── 05-testing.md
├── pyproject.toml            # Project dependencies
├── poetry.lock               # Locked dependencies
├── openapi.json              # Auto-generated OpenAPI spec
├── README.md                 # Project readme
├── STREAMING.md              # Streaming documentation
└── LICENSE                   # License file
```

## Core Concepts

### 1. Request Flow

```
HTTP Request → Router → Service → LLM/Logic → Response
     ↓           ↓         ↓          ↓           ↓
  Pydantic   @log()   Business   OpenAI    StreamingResponse
  Validation  Debug    Logic     Adapter   (AI SDK format)
```

### 2. Streaming Flow

```
Service → LLMStreamer → StreamAdapter → LLM Provider
   ↓           ↓             ↓              ↓
  Create   Orchestrate   Normalize      OpenAI API
  Stream    Pipeline      Chunks        (streaming)
           ↓
      ProtocolFormatter → Client
           ↓                  ↓
      AI SDK Format    JavaScript/Python
      (0:, e:, 3:)     Consumer
```

### 3. Configuration Flow

```
app.main → get_application() → app_factory
   ↓              ↓                 ↓
Create App   Configure        - Routers
   ↓          Everything      - CORS
  ASGI                        - Static files
  App                         - OpenAPI spec
```

## Next Steps

Now that you understand the overview, dive into specific topics:

1. **[File Structure](./01-file-structure.md)** - Learn where everything lives
2. **[Naming Conventions](./02-naming-conventions.md)** - Follow the project's naming patterns
3. **[Architecture](./03-architecture.md)** - Understand the design patterns
4. **[Streaming](./04-streaming.md)** - Master the streaming infrastructure
5. **[Testing](./05-testing.md)** - Write and run tests effectively

## Getting Help

- Check the generated OpenAPI docs at `/docs`
- Look at existing test files for examples
- Read the inline comments in the code
- Review the STREAMING.md for detailed streaming info
- Examine the sample endpoints in `app/routers/sample.py`

## Contributing

When adding features:

1. Follow the existing patterns
2. Add tests for new functionality
3. Update documentation
4. Regenerate OpenAPI spec (runs automatically)
5. Run linters and formatters before committing

## License

MIT License - See LICENSE file for details
