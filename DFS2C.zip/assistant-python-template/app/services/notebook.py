from github import Github
from app.services.github_repos import get_installation_token
from app.utils.utils import create_notebook


def commit_notebook(
    repo_full_name: str,
    branch: str,
    notebook_path: str,
    code: str,
    markdown_intro: str | None,
):
    token = get_installation_token()
    gh = Github(token)

    repo = gh.get_repo(repo_full_name)

    content = create_notebook(code, markdown_intro)

    try:
        existing_file = repo.get_contents(notebook_path, ref=branch)
        repo.update_file(
            path=notebook_path,
            message="Update generated notebook",
            content=content,
            sha=existing_file.sha,
            branch=branch,
        )
    except Exception:
        repo.create_file(
            path=notebook_path,
            message="Create generated notebook",
            content=content,
            branch=branch,
        )

def build_urls(repo_full_name: str, branch: str, notebook_path: str):
    owner, repo = repo_full_name.split("/")

    github_url = (
        f"https://github.com/{owner}/{repo}/blob/{branch}/{notebook_path}"
    )

    colab_url = (
        f"https://colab.research.google.com/github/"
        f"{owner}/{repo}/blob/{branch}/{notebook_path}"
    )

    return github_url, colab_url

