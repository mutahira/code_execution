import json
from typing import Dict

from app.core.streaming.base import ProtocolFormatter


class AISdkFormatter(ProtocolFormatter):
    """Formatter for the AI SDK data stream protocol.

    Format specification:
    - 0:{content}             - Text content chunk
    - e:{metadata}            - End of stream with metadata (finish reason, usage)
    - error:{error_message}   - Error chunk

    Each chunk is terminated with a newline character.
    """

    def format_text_chunk(self, content: str) -> str:
        """
        Format a text content chunk

        :param content: The text content to format
        :return: Formatted string in AI SDK protocol format
        """
        if content is None:
            return ""
        return f"0:{json.dumps(content)}\n"

    def format_finish_chunk(
        self, finish_reason: str, usage: Dict[str, int] | None = None
    ) -> str:
        """
        Format the final chunk indicating stream completion

        :param finish_reason: Reason for stream completion (e.g., "stop", "length")
        :param usage: Optional token usage information with promptTokens and completionTokens
        :return: Formatted string in AI SDK protocol format
        """
        metadata = {
            "finishReason": finish_reason,
            "usage": usage or {"promptTokens": 0, "completionTokens": 0},
            "isContinued": False,
        }
        return f"e:{json.dumps(metadata)}\n"

    def format_error_chunk(self, error: Exception) -> str:
        """
        Format an error chunk

        :param error: The exception that occurred
        :return: Formatted string in AI SDK protocol format
        """
        error_data = {
            "error": str(error),
            "type": error.__class__.__name__,
        }
        return f"3:{json.dumps(error_data)}\n"
