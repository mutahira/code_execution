from typing import Any

from jinja2 import Environment, FileSystemLoader


class PromptBuilder:
    """
    A builder class for creating prompts using Jinja2 templates.
    """

    def __init__(self, template_name: str):
        self.vars = {}
        self.template_name = template_name

    def var(self, key: str, value: Any) -> "PromptBuilder":
        """
        Set a single variable for the template.

        :param key: The variable name in the template.
        :param value: The value to assign to the variable.
        :return: The PromptBuilder instance (for method chaining).
        """
        self.vars[key] = value
        return self

    def vars(self, **kwargs) -> "PromptBuilder":
        """
        Set multiple variables for the template.

        :param kwargs: A dictionary of variable names and their values.
        :return: The PromptBuilder instance (for method chaining).
        """
        for k, v in kwargs.items():
            self.vars[k] = v
        return self

    def build(self) -> str:
        """
        Render the template with the set variables and return the resulting prompt.
        :return: The rendered prompt as a string.
        """
        env = Environment(loader=FileSystemLoader("app/templates/j2"))
        template = env.get_template(self.template_name)
        return template.render(**self.vars)
