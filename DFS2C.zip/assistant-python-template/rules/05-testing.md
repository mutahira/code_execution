# Testing Guide

## Overview

This project uses **pytest** for testing with async support, fixtures, and mocking capabilities. Tests ensure code quality, catch regressions, and serve as documentation.

## Testing Philosophy

### Test Pyramid

```
        ╱╲
       ╱  ╲       Unit Tests (Most)
      ╱────╲      - Fast, isolated
     ╱      ╲     - Test single components
    ╱ Unit   ╲    - Mock dependencies
   ╱──────────╲
  ╱            ╲  Integration Tests (Some)
 ╱ Integration ╲ - Test component interaction
╱────────────────╲ - Use test doubles
────────────────── E2E Tests (Few)
                   - Test complete flows
                   - Use real dependencies
```

### Test Coverage Goals

- **Unit Tests**: 80%+ coverage
- **Integration Tests**: Critical paths
- **E2E Tests**: Key user flows

## Test Structure

### File Organization

```
tests/
├── conftest.py                 # Shared fixtures and configuration
├── test_app_factory.py         # Application initialization tests
├── test_routers.py             # HTTP endpoint tests
│   └── test_sample_router.py
├── test_services.py            # Business logic tests
│   └── test_sample_service.py
├── test_models.py              # Pydantic validation tests
├── test_core.py                # Core utilities tests
│   ├── test_decorators.py
│   └── test_streaming.py
│       ├── test_formatters.py
│       ├── test_adapters.py
│       └── test_streamers.py
└── __pycache__/                # Generated files (don't commit)
```

### Test File Template

```python
"""
Test module for [component name]

Tests:
- [Functionality 1]
- [Functionality 2]
- [Error cases]
"""

import pytest
from unittest.mock import Mock, patch

from app.your_module import YourClass


# Fixtures
@pytest.fixture
def sample_data():
    """Provide test data"""
    return {"key": "value"}


# Unit tests
def test_function_does_something():
    """Test that function performs expected action"""
    # Arrange
    input_data = "test"

    # Act
    result = function_under_test(input_data)

    # Assert
    assert result == expected_output


def test_function_handles_error():
    """Test that function raises expected error"""
    with pytest.raises(ValueError, match="expected message"):
        function_under_test(invalid_input)


# Async tests
@pytest.mark.asyncio
async def test_async_function():
    """Test async function"""
    result = await async_function()
    assert result is not None
```

## Running Tests

### Basic Commands

```bash
# Run all tests
pytest

# Run with output
pytest -v

# Run specific file
pytest tests/test_sample_router.py

# Run specific test
pytest tests/test_sample_router.py::test_show_me_endpoint_returns_prompt

# Run tests matching pattern
pytest -k "router"

# Run with coverage
pytest --cov=app

# Generate HTML coverage report
pytest --cov=app --cov-report=html

# Run in parallel (requires pytest-xdist)
pytest -n auto
```

### Using Poetry

```bash
# Run tests
poetry run pytest

# With coverage
poetry run pytest --cov=app --cov-report=html

# Run specific test
poetry run pytest tests/test_sample_router.py -v
```

### Configuration

**pyproject.toml:**
```toml
[tool.pytest.ini_options]
asyncio_mode = "auto"                          # Auto-detect async tests
asyncio_default_fixture_loop_scope = "function"  # Fixture scope
testpaths = ["tests"]                          # Test directory
```

## Testing Patterns

### 1. Unit Testing Functions

**Example: Testing helper functions**

```python
# app/services/sample.py
def get_prompt(city: str) -> str:
    if "error" in city.lower():
        raise IncorrectAPIInvocationError("Invalid city")

    return PromptBuilder("prompt.j2").var("city", city).build()


# tests/test_sample_service.py
def test_get_prompt_success():
    """Test prompt generation for valid city"""
    prompt = get_prompt("Berlin")

    assert "Berlin" in prompt
    assert len(prompt) > 0


def test_get_prompt_rejects_invalid_city():
    """Test that invalid city raises error"""
    with pytest.raises(IncorrectAPIInvocationError):
        get_prompt("error town")
```

### 2. Unit Testing Classes

**Example: Testing service initialization**

```python
# app/services/sample.py
class SampleStreamingService(BaseStreamingService):
    def __init__(self):
        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY required")
        self.client = AsyncOpenAI(api_key=api_key)


# tests/test_sample_service.py
def test_service_requires_api_key(monkeypatch):
    """Test service fails without API key"""
    # Remove environment variable
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)

    # Should raise ValueError
    with pytest.raises(ValueError, match="OPENAI_API_KEY"):
        SampleStreamingService()


def test_service_initializes_with_api_key(monkeypatch):
    """Test service initializes with API key"""
    # Set environment variable
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")

    # Mock AsyncOpenAI
    class MockClient:
        def __init__(self, api_key):
            self.api_key = api_key

    monkeypatch.setattr("app.services.sample.AsyncOpenAI", MockClient)

    # Should initialize successfully
    service = SampleStreamingService()
    assert service.client.api_key == "test-key"
```

### 3. Testing with Mocks

**Using monkeypatch (pytest built-in):**

```python
def test_service_calls_openai(monkeypatch):
    """Test service makes correct OpenAI call"""
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")

    # Track calls
    captured = {}

    class MockClient:
        def __init__(self, api_key):
            self.api_key = api_key

        class chat:
            class completions:
                @staticmethod
                async def create(**kwargs):
                    captured["kwargs"] = kwargs
                    return mock_response

    # Inject mock
    monkeypatch.setattr(
        "app.services.sample.AsyncOpenAI",
        MockClient
    )

    # Test
    service = SampleStreamingService()
    await service.ask_about_city("Paris", model="gpt-4o")

    # Verify
    assert captured["kwargs"]["model"] == "gpt-4o"
    assert any("Paris" in str(msg) for msg in captured["kwargs"]["messages"])
```

**Using unittest.mock:**

```python
from unittest.mock import Mock, patch, AsyncMock

@patch('app.services.sample.AsyncOpenAI')
def test_service_with_patch(mock_openai_class):
    """Test using patch decorator"""
    # Configure mock
    mock_client = Mock()
    mock_openai_class.return_value = mock_client

    # Set environment
    os.environ["OPENAI_API_KEY"] = "test-key"

    # Test
    service = SampleStreamingService()

    # Verify
    mock_openai_class.assert_called_once_with(api_key="test-key")
    assert service.client == mock_client
```

### 4. Testing Async Code

**Basic async test:**

```python
@pytest.mark.asyncio
async def test_async_stream_adapter():
    """Test async streaming adapter"""
    # Create mock stream
    async def mock_stream():
        yield StreamChunk(content="Hello")
        yield StreamChunk(content=" world")

    # Test adapter
    adapter = MockAdapter()
    chunks = []

    async for chunk in adapter.stream([]):
        chunks.append(chunk)

    assert len(chunks) == 2
    assert chunks[0].content == "Hello"
```

**Testing with async context managers:**

```python
@pytest.mark.asyncio
async def test_streaming_with_context_manager():
    """Test streaming using context manager"""
    async with create_test_stream() as stream:
        chunks = []
        async for chunk in stream:
            chunks.append(chunk)

        assert len(chunks) > 0
```

### 5. Testing Routers

**Using FastAPI TestClient:**

```python
from fastapi import FastAPI
from fastapi.testclient import TestClient

def test_router_endpoint(monkeypatch):
    """Test router returns correct response"""
    # Create test app
    app = FastAPI()
    app.include_router(sample.router)
    client = TestClient(app)

    # Mock service
    class MockService:
        def ask_about_city(self, city, model):
            return {"response": f"Info about {city}"}

    monkeypatch.setattr(
        "app.routers.sample.SampleStreamingService",
        MockService
    )

    # Make request
    response = client.post(
        "/sample/city",
        json={"city": "Paris", "model": "gpt-4o"}
    )

    # Verify
    assert response.status_code == 200
    assert "Paris" in response.json()["response"]


def test_router_validates_input():
    """Test router validates request model"""
    app = FastAPI()
    app.include_router(sample.router)
    client = TestClient(app)

    # Send invalid request (missing required field)
    response = client.post("/sample/city", json={})

    # Should return validation error
    assert response.status_code == 422
    assert "city" in response.json()["detail"][0]["loc"]
```

### 6. Testing Streaming Endpoints

**Testing with streaming stub:**

```python
from collections import deque

class StreamingStub:
    """Stub that returns predefined chunks"""
    def __init__(self, chunks):
        self.chunks = chunks
        self.calls = deque()

    def ask_about_city(self, city, model):
        self.calls.append((city, model))

        async def generator():
            for chunk in self.chunks:
                yield chunk

        return StreamingResponse(
            generator(),
            media_type="text/event-stream"
        )


def test_streaming_endpoint(monkeypatch):
    """Test streaming endpoint returns chunks"""
    # Create stub with predefined chunks
    stub = StreamingStub(["0:chunk1", "0:chunk2", "e:end"])

    # Inject stub
    monkeypatch.setattr(
        "app.routers.sample.SampleStreamingService",
        lambda: stub
    )

    # Create client
    app = FastAPI()
    app.include_router(sample.router)
    client = TestClient(app)

    # Make request
    response = client.post(
        "/sample/city",
        json={"city": "Lisbon", "model": "gpt-4o"}
    )

    # Verify
    assert response.status_code == 200
    assert stub.calls.pop() == ("Lisbon", "gpt-4o")

    content = response.content.decode()
    assert "0:chunk1" in content
    assert "0:chunk2" in content
    assert "e:end" in content
```

### 7. Testing Pydantic Models

**Testing validation:**

```python
def test_city_request_validates_city():
    """Test model validates city field"""
    # Valid request
    request = CityRequest(city="Paris", model="gpt-4o")
    assert request.city == "Paris"
    assert request.model == "gpt-4o"


def test_city_request_requires_city():
    """Test model requires city field"""
    with pytest.raises(ValidationError) as exc_info:
        CityRequest(model="gpt-4o")

    errors = exc_info.value.errors()
    assert any(e["loc"] == ("city",) for e in errors)


def test_city_request_validates_min_length():
    """Test model enforces min length"""
    with pytest.raises(ValidationError):
        CityRequest(city="", model="gpt-4o")


def test_city_request_uses_default_model():
    """Test model provides default for optional field"""
    request = CityRequest(city="Paris")
    assert request.model == "gpt-4o"  # Default value
```

### 8. Testing Formatters

**Testing output format:**

```python
def test_formatter_formats_text_chunk():
    """Test formatter produces correct text chunk format"""
    formatter = AISdkFormatter()
    result = formatter.format_text_chunk("hello")

    # Verify format
    assert result == '0:"hello"\n'
    assert result.startswith('0:')
    assert result.endswith('\n')


def test_formatter_handles_none_content():
    """Test formatter handles None gracefully"""
    formatter = AISdkFormatter()
    result = formatter.format_text_chunk(None)

    assert result == ""


def test_formatter_formats_finish_chunk():
    """Test formatter produces correct finish chunk"""
    formatter = AISdkFormatter()
    result = formatter.format_finish_chunk(
        "stop",
        usage={"promptTokens": 10, "completionTokens": 20}
    )

    # Verify format
    assert result.startswith('e:')
    assert '"finishReason": "stop"' in result
    assert '"promptTokens": 10' in result
    assert '"completionTokens": 20' in result
    assert '"isContinued": false' in result


def test_formatter_includes_default_usage():
    """Test formatter provides default usage when not specified"""
    formatter = AISdkFormatter()
    result = formatter.format_finish_chunk("stop")

    assert '"promptTokens": 0' in result
    assert '"completionTokens": 0' in result


def test_formatter_formats_error_chunk():
    """Test formatter produces correct error chunk"""
    formatter = AISdkFormatter()
    error = ValueError("bad input")
    result = formatter.format_error_chunk(error)

    # Verify format
    assert result.startswith('3:')
    assert '"error": "bad input"' in result
    assert '"type": "ValueError"' in result
```

### 9. Testing Adapters

**Testing OpenAI adapter:**

```python
@pytest.mark.asyncio
async def test_adapter_converts_openai_chunks():
    """Test adapter converts OpenAI format to StreamChunk"""

    # Mock OpenAI response
    class MockDelta:
        def __init__(self, content):
            self.content = content

    class MockChoice:
        def __init__(self, delta, finish_reason=None):
            self.delta = delta
            self.finish_reason = finish_reason

    class MockChunk:
        def __init__(self, content=None, finish_reason=None):
            self.choices = [MockChoice(
                MockDelta(content),
                finish_reason
            )]
            self.usage = None

    class MockStream:
        async def __aiter__(self):
            yield MockChunk(content="Hello")
            yield MockChunk(content=" world")
            yield MockChunk(finish_reason="stop")

    class MockClient:
        class chat:
            class completions:
                @staticmethod
                async def create(**kwargs):
                    return MockStream()

    # Test adapter
    adapter = OpenAIStreamAdapter(MockClient(), model="gpt-4o")
    chunks = []

    async for chunk in adapter.stream([{"role": "user", "content": "Hi"}]):
        chunks.append(chunk)

    # Verify conversion
    assert len(chunks) == 3
    assert chunks[0].content == "Hello"
    assert chunks[1].content == " world"
    assert chunks[2].finish_reason == "stop"


@pytest.mark.asyncio
async def test_adapter_passes_parameters():
    """Test adapter passes parameters to OpenAI"""
    captured = {}

    class MockClient:
        class chat:
            class completions:
                @staticmethod
                async def create(**kwargs):
                    captured["params"] = kwargs

                    class EmptyStream:
                        async def __aiter__(self):
                            return
                            yield  # Make it a generator

                    return EmptyStream()

    # Test with custom parameters
    adapter = OpenAIStreamAdapter(
        MockClient(),
        model="gpt-4o",
        temperature=0.8,
        max_tokens=500
    )

    messages = [{"role": "user", "content": "Hello"}]
    async for _ in adapter.stream(messages):
        pass

    # Verify parameters
    assert captured["params"]["model"] == "gpt-4o"
    assert captured["params"]["temperature"] == 0.8
    assert captured["params"]["max_tokens"] == 500
    assert captured["params"]["stream"] is True
```

### 10. Testing Streamers

**Testing LLMStreamer:**

```python
@pytest.mark.asyncio
async def test_streamer_orchestrates_adapter_and_formatter():
    """Test streamer combines adapter and formatter correctly"""

    # Mock adapter
    class MockAdapter:
        async def stream(self, messages, **kwargs):
            yield StreamChunk(content="Hello")
            yield StreamChunk(content=" world")
            yield StreamChunk(finish_reason="stop")

    # Mock formatter
    class MockFormatter:
        def format_text_chunk(self, content):
            return f"TEXT:{content}\n"

        def format_finish_chunk(self, reason, usage=None):
            return f"FINISH:{reason}\n"

        def format_error_chunk(self, error):
            return f"ERROR:{error}\n"

    # Test streamer
    streamer = LLMStreamer(MockAdapter(), MockFormatter())
    response = streamer.stream([{"role": "user", "content": "Hi"}])

    # Verify it's a StreamingResponse
    assert isinstance(response, StreamingResponse)

    # Verify headers
    assert response.headers["x-vercel-ai-data-stream"] == "v1"
    assert response.headers["Content-Type"] == "text/event-stream"

    # Collect chunks
    chunks = []
    async for chunk in response.body_iterator:
        chunks.append(chunk)

    # Verify formatting
    assert b"TEXT:Hello\n" in chunks
    assert b"TEXT: world\n" in chunks
    assert b"FINISH:stop\n" in chunks
```

## Fixtures

### Built-in Fixtures

**conftest.py:**

```python
import sys
from pathlib import Path

# Add project root to path
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


@pytest.fixture
def app():
    """Create FastAPI app for testing"""
    from app.app_factory import get_application
    return get_application()


@pytest.fixture
def client(app):
    """Create test client"""
    from fastapi.testclient import TestClient
    return TestClient(app)


@pytest.fixture
def mock_openai_client(monkeypatch):
    """Mock OpenAI client"""
    class MockClient:
        def __init__(self, api_key):
            self.api_key = api_key

    monkeypatch.setattr("openai.AsyncOpenAI", MockClient)
    return MockClient


@pytest.fixture
def sample_messages():
    """Provide sample message list"""
    return [
        {"role": "system", "content": "You are helpful."},
        {"role": "user", "content": "Hello"}
    ]


@pytest.fixture(autouse=True)
def reset_env(monkeypatch):
    """Reset environment variables after each test"""
    # This runs automatically for every test
    yield
    # Cleanup happens here
```

### Custom Fixtures

**Test-specific fixtures:**

```python
@pytest.fixture
def sample_city_request():
    """Provide sample CityRequest"""
    return CityRequest(city="Paris", model="gpt-4o")


@pytest.fixture
def streaming_stub():
    """Provide streaming service stub"""
    class Stub:
        def __init__(self):
            self.calls = []

        def ask_about_city(self, city, model):
            self.calls.append(("city", city, model))

            async def gen():
                yield "0:response"

            return StreamingResponse(gen())

    return Stub()


@pytest.fixture
async def async_openai_stream():
    """Provide async OpenAI stream mock"""
    async def stream():
        yield MockChunk(content="test")

    return stream()
```

## Code Coverage

### Running Coverage

```bash
# Basic coverage
pytest --cov=app

# With HTML report
pytest --cov=app --cov-report=html

# With terminal report
pytest --cov=app --cov-report=term

# Fail if coverage below threshold
pytest --cov=app --cov-fail-under=80
```

### Coverage Report

```bash
# View HTML report
open htmlcov/index.html  # macOS
xdg-open htmlcov/index.html  # Linux
```

### Coverage Configuration

**pyproject.toml:**

```toml
[tool.coverage.run]
source = ["app"]
omit = [
    "*/tests/*",
    "*/__pycache__/*",
    "*/venv/*"
]

[tool.coverage.report]
exclude_lines = [
    "pragma: no cover",
    "def __repr__",
    "raise AssertionError",
    "raise NotImplementedError",
    "if __name__ == .__main__.:",
]
```

## Best Practices

### Test Organization

✅ **Do:**
- One test file per source file
- Group related tests in classes
- Use descriptive test names
- Follow Arrange-Act-Assert pattern
- Test one thing per test

❌ **Don't:**
- Mix unit and integration tests
- Create massive test files
- Use generic test names like `test_1()`
- Test multiple behaviors in one test
- Skip cleanup after tests

### Mocking

✅ **Do:**
- Mock external dependencies (API calls, database)
- Use monkeypatch for environment variables
- Verify mock interactions
- Reset mocks between tests
- Mock at the right boundary

❌ **Don't:**
- Mock internal logic you're testing
- Over-mock (makes tests brittle)
- Share mocks between tests
- Forget to verify mock calls
- Mock too high in the stack

### Assertions

✅ **Do:**
- Use specific assertions
- Include helpful error messages
- Test edge cases
- Test error conditions
- Verify side effects

❌ **Don't:**
- Use bare `assert True`
- Skip negative tests
- Ignore exceptions
- Test implementation details
- Have tests without assertions

### Test Data

✅ **Do:**
- Use fixtures for reusable data
- Create minimal test data
- Use realistic data
- Clean up after tests
- Use factories for complex objects

❌ **Don't:**
- Hardcode data in tests
- Use production data
- Share mutable fixtures
- Leave test data around
- Create overly complex test data

## Continuous Integration

### GitHub Actions Example

```yaml
# .github/workflows/test.yml
name: Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest

    steps:
    - uses: actions/checkout@v3

    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.11'

    - name: Install dependencies
      run: |
        pip install poetry
        poetry install

    - name: Run tests
      run: |
        poetry run pytest --cov=app --cov-report=xml

    - name: Upload coverage
      uses: codecov/codecov-action@v3
      with:
        file: ./coverage.xml
```

## Debugging Tests

### Running Single Test

```bash
# Run one test
pytest tests/test_sample_router.py::test_show_me_endpoint_returns_prompt -v

# Run with print statements
pytest tests/test_sample_router.py -s

# Run with debugger
pytest tests/test_sample_router.py --pdb

# Stop on first failure
pytest -x

# Show local variables on failure
pytest -l
```

### Using pdb

```python
def test_something():
    """Test with debugger"""
    data = {"key": "value"}

    # Drop into debugger
    import pdb; pdb.set_trace()

    result = function(data)
    assert result is not None
```

### Debugging Async Tests

```python
@pytest.mark.asyncio
async def test_async_function():
    """Debug async test"""
    import pdb

    result = await async_function()
    pdb.set_trace()  # Inspect async result

    assert result is not None
```

## Common Testing Patterns

### Testing Error Handling

```python
def test_function_raises_on_invalid_input():
    """Test error is raised correctly"""
    with pytest.raises(ValueError, match="invalid input"):
        function_under_test("invalid")


def test_function_handles_missing_key():
    """Test KeyError is handled"""
    with pytest.raises(KeyError):
        function_under_test({})


def test_custom_exception():
    """Test custom exception"""
    with pytest.raises(IncorrectAPIInvocationError) as exc_info:
        function_that_fails()

    assert "specific message" in str(exc_info.value)
```

### Testing with Parametrize

```python
@pytest.mark.parametrize("city,expected", [
    ("Paris", "France"),
    ("London", "UK"),
    ("Tokyo", "Japan"),
])
def test_get_country(city, expected):
    """Test function with multiple inputs"""
    result = get_country(city)
    assert result == expected


@pytest.mark.parametrize("invalid_input", [
    "",
    "error",
    "bad input",
    None,
])
def test_validation_rejects_invalid(invalid_input):
    """Test validation rejects various invalid inputs"""
    with pytest.raises(ValueError):
        validate(invalid_input)
```

### Testing with Temporary Files

```python
def test_reads_file(tmp_path):
    """Test file reading using tmp_path fixture"""
    # Create temp file
    test_file = tmp_path / "test.txt"
    test_file.write_text("test content")

    # Test
    result = read_file(test_file)

    # Verify
    assert result == "test content"

    # tmp_path is automatically cleaned up
```

## Quick Reference

### Test Decorators

```python
@pytest.mark.asyncio              # Mark as async test
@pytest.mark.parametrize(...)     # Run with multiple inputs
@pytest.mark.skip("reason")       # Skip test
@pytest.mark.skipif(...)          # Conditionally skip
@pytest.mark.xfail("reason")      # Expected to fail
```

### Common Assertions

```python
assert value == expected
assert value is True
assert value is not None
assert "substring" in string
assert isinstance(obj, Class)
assert len(list) == 3
```

### Common Fixtures

```python
monkeypatch    # Mock/patch objects
tmp_path       # Temporary directory
capsys         # Capture stdout/stderr
caplog         # Capture log messages
```

### Running Tests

```bash
pytest                    # Run all
pytest -v                 # Verbose
pytest -s                 # Show prints
pytest -x                 # Stop on first failure
pytest -k "pattern"       # Run matching tests
pytest --lf               # Run last failed
pytest --ff               # Run failures first
pytest --cov=app          # With coverage
```

---

**Congratulations!** You now have comprehensive documentation for the entire project. Refer to these guides as you develop and extend the application.
