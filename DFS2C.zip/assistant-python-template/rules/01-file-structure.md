# File Structure and Organization

## Directory Layout

This document explains where files belong and why.

## Root Level Files

### Configuration Files

```
pyproject.toml       # Poetry configuration & dependencies
poetry.lock          # Locked dependency versions
setup.cfg            # Tool configurations (flake8, etc.)
.gitignore           # Git ignore patterns
```

**When to modify:**
- Add new dependencies: Edit `pyproject.toml` and run `poetry lock`
- Change tool settings: Edit `setup.cfg`

### Documentation Files

```
README.md            # Project introduction
STREAMING.md         # Streaming infrastructure guide
LICENSE              # Project license
```

**When to modify:**
- Update project description or setup instructions
- Document new features

### Generated Files

```
openapi.json         # Auto-generated OpenAPI specification
```

**⚠️ IMPORTANT:** Never edit `openapi.json` manually! It's regenerated on app startup from your route definitions.

## Application Directory (`app/`)

### Core Application Files

#### `app/main.py`

**Purpose:** Application entry point - creates and runs the ASGI app

**When to modify:**
- Rarely! Most configuration belongs in `app_factory.py`

**Example:**
```python
from app.app_factory import get_application

app = get_application()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
```

#### `app/app_factory.py`

**Purpose:** Application factory - configures routers, middleware, static files

**When to modify:**
- Add new routers to `__configure_routers()`
- Change CORS policy in `_configure_cors_policy()`
- Add middleware

**Pattern:**
```python
def __configure_routers(app: FastAPI):
    app.include_router(sample.router)
    app.include_router(your_new_router.router)  # Add here
```

#### `app/errors.py`

**Purpose:** Custom exception classes

**When to modify:**
- Add new exception types for specific error conditions

**Pattern:**
```python
class YourCustomError(HTTPException):
    def __init__(self, msg: str):
        super().__init__(status_code=400, detail=msg)
```

### Routers Directory (`app/routers/`)

**Purpose:** HTTP endpoint definitions (FastAPI routes)

**File naming:** Use descriptive nouns, e.g., `user.py`, `chat.py`, `documents.py`

**Structure:**
```
app/routers/
├── __init__.py          # Empty or exports
├── sample.py            # Example routes
├── chat.py              # Your chat routes
└── documents.py         # Your document routes
```

**Router Template:**
```python
import http
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse

from app.core.decorators import log
from app.models.your_model import RequestModel, ResponseModel
from app.services.your_service import YourService

# Create router with prefix and tags
router = APIRouter(prefix="/api-prefix", tags=["Tag Name"])

@router.post(
    "/endpoint",
    status_code=http.HTTPStatus.OK,
    response_model=ResponseModel,  # For non-streaming
)
@log(__name__)  # Add debug logging
def your_endpoint(request: RequestModel):
    """
    Detailed docstring explaining:
    - What the endpoint does
    - Request format
    - Response format
    - Example usage
    """
    try:
        service = YourService()
        return service.do_something(request)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")
```

**⚠️ Important Rules:**

1. **Keep routers thin** - Only handle HTTP concerns (validation, status codes)
2. **Business logic goes in services** - Not in routers
3. **Always use `@log(__name__)`** - For debugging
4. **Use proper status codes** - Import from `http.HTTPStatus`
5. **Document with docstrings** - They appear in OpenAPI docs

### Services Directory (`app/services/`)

**Purpose:** Business logic and LLM orchestration

**File naming:** Match router names, e.g., `chat.py` service for `chat.py` router

**Structure:**
```
app/services/
├── __init__.py          # Empty or exports
├── base.py              # Base service classes
├── sample.py            # Example services
└── your_service.py      # Your business logic
```

**Service Template:**
```python
import os
from fastapi.responses import StreamingResponse
from openai import AsyncOpenAI

from app.services.base import BaseStreamingService
from app.templates.builder import PromptBuilder

class YourService(BaseStreamingService):
    """
    Service that handles [specific functionality]

    This service demonstrates:
    - How to initialize dependencies
    - How to validate environment variables
    - How to use streaming infrastructure
    """

    def __init__(self):
        """Initialize with required dependencies."""
        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY required")

        self.client = AsyncOpenAI(api_key=api_key)

    def your_method(self, param: str) -> StreamingResponse:
        """
        Business logic method.

        :param param: Description
        :return: StreamingResponse or regular response
        """
        # 1. Validate inputs
        if not param:
            raise ValueError("Parameter required")

        # 2. Build prompts (if using LLM)
        prompt = PromptBuilder("template.j2") \
            .var("key", param) \
            .build()

        # 3. Prepare messages
        messages = [
            {"role": "system", "content": "System prompt"},
            {"role": "user", "content": prompt}
        ]

        # 4. Stream response
        return self.create_stream_response(
            client=self.client,
            messages=messages,
            model="gpt-4o",
            temperature=0.7  # Additional OpenAI params
        )
```

**⚠️ Important Rules:**

1. **Inherit from `BaseStreamingService`** - For streaming capabilities
2. **Validate in `__init__`** - Fail fast for missing environment variables
3. **Use helper methods** - For complex prompt building or validation
4. **Return proper types** - `StreamingResponse` or Pydantic models
5. **Handle errors** - Raise descriptive `ValueError` for client errors

### Models Directory (`app/models/`)

**Purpose:** Pydantic models for request/response validation

**File naming:** Match router/service names

**Structure:**
```
app/models/
├── __init__.py          # Empty or exports
├── sample.py            # Example models
└── your_models.py       # Your data models
```

**Model Template:**
```python
from pydantic import BaseModel, Field

class YourRequest(BaseModel):
    """Request model for your endpoint"""

    field_name: str = Field(
        ...,  # Required field
        description="Human-readable description",
        min_length=1,
        max_length=500,
        examples=["Example 1", "Example 2"]
    )

    optional_field: str | None = Field(
        default=None,
        description="Optional field description",
        examples=["default-value"]
    )

class YourResponse(BaseModel):
    """Response model for your endpoint"""

    success: bool = Field(
        ...,
        description="Operation success indicator"
    )

    data: dict | None = Field(
        None,
        description="Response data"
    )
```

**⚠️ Important Rules:**

1. **Use Pydantic v2 syntax** - `str | None` not `Optional[str]`
2. **Add descriptions** - They appear in OpenAPI docs
3. **Provide examples** - Makes docs more useful
4. **Set validation rules** - min_length, max_length, patterns
5. **Document all fields** - Even obvious ones

### Core Directory (`app/core/`)

**Purpose:** Reusable utilities and infrastructure

**Structure:**
```
app/core/
├── __init__.py
├── decorators.py            # Logging decorators
└── streaming/               # Streaming infrastructure
    ├── __init__.py
    ├── base.py              # Abstract base classes
    ├── formatters.py        # Protocol formatters
    ├── adapters/            # LLM provider adapters
    │   ├── __init__.py
    │   └── openai.py
    └── streamers/           # Stream orchestrators
        ├── __init__.py
        ├── llm.py           # LLM streaming
        └── text.py          # Text streaming
```

**When to add files here:**
- Creating decorators used across the app
- Implementing new LLM provider adapters
- Adding new protocol formatters
- Building reusable utilities

**⚠️ Important:** This is infrastructure code - don't put business logic here!

### Templates Directory (`app/templates/`)

**Purpose:** Jinja2 templates for prompt building

**Structure:**
```
app/templates/
├── builder.py               # PromptBuilder class
└── j2/                      # Jinja2 template files
    ├── prompt.j2
    └── your_template.j2
```

**Template Example (`j2/your_template.j2`):**
```jinja
You are a {{ role }} assistant. {{ additional_context }}

User query: {{ user_input }}

{% if include_examples %}
Examples:
{% for example in examples %}
- {{ example }}
{% endfor %}
{% endif %}
```

**Usage Example:**
```python
from app.templates.builder import PromptBuilder

prompt = PromptBuilder("your_template.j2") \
    .var("role", "helpful") \
    .var("user_input", "Hello") \
    .var("include_examples", True) \
    .var("examples", ["ex1", "ex2"]) \
    .build()
```

**⚠️ Template Rules:**

1. **Keep templates focused** - One template per prompt type
2. **Use descriptive variable names** - `{{ user_query }}` not `{{ q }}`
3. **Document expected variables** - In comments at the top
4. **Use Jinja2 features** - Conditionals, loops, filters

### Static Directory (`app/static/`)

**Purpose:** HTML demos, CSS, JavaScript, and static assets

**Structure:**
```
app/static/
├── index.html               # Landing page
├── streaming-demo.html      # Interactive streaming demo
├── styles.css               # (if needed)
└── scripts.js               # (if needed)
```

**When to add files:**
- Creating demos for testing endpoints
- Adding documentation pages
- Including client-side JavaScript examples

## Tests Directory (`tests/`)

**Structure:**
```
tests/
├── conftest.py              # Pytest fixtures and configuration
├── test_app_factory.py      # Test app creation
├── test_routers.py          # Test route handlers
├── test_services.py         # Test business logic
├── test_models.py           # Test Pydantic models
├── test_streaming.py        # Test streaming infrastructure
└── __pycache__/             # Generated, don't commit
```

**File Naming Rules:**

- Prefix all test files with `test_`
- Match source file names: `sample.py` → `test_sample.py`
- Group related tests: `test_sample_router.py`, `test_sample_service.py`

**What to test where:**

| Test File | What to Test |
|-----------|--------------|
| `test_*_router.py` | HTTP endpoint behavior, status codes, error handling |
| `test_*_service.py` | Business logic, prompt generation, validation |
| `test_*_models.py` | Pydantic validation, field constraints |
| `test_streaming.py` | Streaming infrastructure, formatters, adapters |

## File Naming Conventions Summary

### Python Files

```
✅ Good:
- user_service.py
- chat_router.py
- document_models.py
- openai_adapter.py

❌ Bad:
- UserService.py          # Don't use PascalCase
- chatRouter.py           # Don't use camelCase
- doc-models.py           # Don't use hyphens
- service12.py            # Use descriptive names
```

### Template Files

```
✅ Good:
- user_prompt.j2
- chat_system.j2
- document_analysis.j2

❌ Bad:
- template1.j2            # Not descriptive
- UserPrompt.j2           # Don't use PascalCase
```

### Test Files

```
✅ Good:
- test_user_router.py
- test_chat_service.py
- test_document_models.py

❌ Bad:
- user_test.py            # Must start with test_
- test_User.py            # Don't use PascalCase
```

## Import Organization

Within each file, organize imports in this order:

```python
import os
from pathlib import Path
from typing import Any, Dict, List

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from openai import AsyncOpenAI

from app.core.decorators import log
from app.models.sample import SampleRequest
from app.services.sample import SampleService
```

Use `isort` to automatically organize imports:
```bash
poetry run isort app/
```

This will be handled via the pre-commit hooks

## Path References

When referencing paths in code:

```python
# ✅ Good: Use Path from pathlib
from pathlib import Path

static_dir = Path(__file__).parent / "static"
template_dir = Path(__file__).parent / "templates" / "j2"

# ✅ Good: Relative to project root
template_loader = FileSystemLoader("app/templates/j2")

# ❌ Bad: Hardcoded absolute paths
template_loader = FileSystemLoader("/home/user/project/app/templates/j2")

# ❌ Bad: OS-specific path separators
template_dir = "app\\templates\\j2"  # Windows-only
```

## Summary

### Quick Reference

| File Type | Location | Naming | Purpose |
|-----------|----------|--------|---------|
| Routes | `app/routers/` | `noun.py` | HTTP endpoints |
| Services | `app/services/` | `noun.py` | Business logic |
| Models | `app/models/` | `noun.py` | Data validation |
| Templates | `app/templates/j2/` | `purpose.j2` | Prompts |
| Tests | `tests/` | `test_noun.py` | Unit tests |
| Adapters | `app/core/streaming/adapters/` | `provider.py` | LLM integration |
| Formatters | `app/core/streaming/` | `formatters.py` | Output formats |

### Key Principles

1. **Separation of Concerns**: Routers handle HTTP, services handle logic
2. **Descriptive Names**: Files and variables should be self-documenting
3. **Consistent Structure**: Follow established patterns for new features
4. **Type Safety**: Use type hints everywhere
5. **Auto-generation**: Let tools generate what they can (OpenAPI, coverage)

---

**Next:** [Naming Conventions](./02-naming-conventions.md) - Learn how to name classes, functions, and variables
