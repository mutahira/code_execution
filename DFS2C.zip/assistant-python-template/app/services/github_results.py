
from app.services.github_repos import get_installation_token

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel  
from typing import Any
import uuid
import requests

def upload_to_github(owner, repo, branch, installation_id, path, content_base64):
    token = get_installation_token(int(installation_id))

    url = f"https://api.github.com/repos/{owner}/{repo}/contents/{path}"

    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github+json"
    }

    data = {
        "message": f"Update result file: {path}",
        "content": content_base64,
        "branch": branch
    }

    # Try create first
    response = requests.put(url, headers=headers, json=data)

    # If file exists → update
    if response.status_code == 422:
        existing = requests.get(url, headers=headers, params={"ref": branch})

        if existing.status_code == 200:
            sha = existing.json()["sha"]
            data["sha"] = sha

            response = requests.put(url, headers=headers, json=data)

    response.raise_for_status()
    return response.json()