from github import GithubIntegration

from pathlib import Path
if(Path("C:/Users/KhalidM/Desktop/ORKG_Research/Data-Analysis/Github_records/dataanalysisassistant.2026-01-05.private-key.pem").exists()):
    print("KEY FILE EXISTS")


with open("C:/Users/KhalidM/Desktop/ORKG_Research/Data-Analysis/Github_records/dataanalysisassistant.2026-01-05.private-key.pem", "r", encoding="utf-8") as f:
    key = f.read()

print(key[:30])
print(key[-30:])

GithubIntegration(2600628, key)  # replace with real App ID
print("KEY IS VALID")
