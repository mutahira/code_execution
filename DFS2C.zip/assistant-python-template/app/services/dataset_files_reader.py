import os
import requests
from typing import Dict

def dataset_files_reader(path_or_url: str, num_lines: int = 10) -> Dict[str, str]:
    """
    Load first `num_lines` of file(s) from local path, URL, or directory.
    Returns a dict: file_name -> first N lines as string.
    """
    files_content: Dict[str, str] = {}

    # --- Directory ---
    if os.path.isdir(path_or_url):
        for fname in os.listdir(path_or_url):
            fpath = os.path.join(path_or_url, fname)
            if os.path.isfile(fpath):
                with open(fpath, "r", encoding="utf-8") as f:
                    lines = [next(f) for _ in range(num_lines)]
                    files_content[fname] = "".join(lines)

    # --- URL or single file ---
    else:
        if path_or_url.startswith("http"):
            r = requests.get(path_or_url)
            if r.status_code != 200:
                raise ValueError(f"Unable to download file: {path_or_url}")
            fname = os.path.basename(path_or_url)
            files_content[fname] = "\n".join(r.text.splitlines()[:num_lines])
        else:
            # Local single file
            if not os.path.exists(path_or_url):
                raise ValueError(f"File not found: {path_or_url}")
            fname = os.path.basename(path_or_url)
            with open(path_or_url, "r", encoding="utf-8") as f:
                lines = [next(f) for _ in range(num_lines)]
                files_content[fname] = "".join(lines)

    return files_content
