import requests
from github import GithubIntegration
from dotenv import load_dotenv
import os

load_dotenv()

GITHUB_APP_ID = os.getenv("GITHUB_APP_ID")
GITHUB_PRIVATE_KEY_PATH = os.getenv("GITHUB_PRIVATE_KEY_PATH")


def get_installation_token(installation_id: int) -> str:
    with open(GITHUB_PRIVATE_KEY_PATH, "r") as f:
        private_key = f.read()

    integration = GithubIntegration(
        GITHUB_APP_ID,
        private_key
    )

    return integration.get_access_token(installation_id).token


def list_repositories(installation_id: int):
    token = get_installation_token(installation_id)

    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
    }

    resp = requests.get(
        "https://api.github.com/installation/repositories",
        headers=headers,
        timeout=10,
    )

    resp.raise_for_status()

    data = resp.json()

    repos = []
    for repo in data.get("repositories", []):
        repos.append({
            "full_name": repo["full_name"],
            "name": repo["name"],
            "owner": repo["owner"]["login"],
            "default_branch": repo["default_branch"],
            "private": repo["private"],
        })

    return repos
